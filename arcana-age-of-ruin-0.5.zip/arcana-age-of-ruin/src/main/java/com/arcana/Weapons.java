package com.arcana;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.AttributeModifierSlot;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.component.type.CustomModelDataComponent;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.List;

/** Редкость хранится в custom_data стака, так что на класс приходится один предмет. */
public final class Weapons {
    public static ItemStack create(ArcanaClass c, Rarity r) {
        ItemStack s = new ItemStack(ModItems.WEAPONS.get(c));
        init(s, c, r);
        return s;
    }

    /** Выставляет редкость, имя и характеристики на готовом стаке оружия. */
    public static void init(ItemStack s, ArcanaClass c, Rarity r) {
        NbtCompound nbt = new NbtCompound();
        nbt.putInt("rarity", r.ordinal());
        s.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(nbt));
        s.set(DataComponentTypes.CUSTOM_MODEL_DATA, new CustomModelDataComponent(r.ordinal()));
        s.set(DataComponentTypes.CUSTOM_NAME, Text.literal(c.weaponName).styled(st -> st.withItalic(false).withColor(r.color)));
        s.set(DataComponentTypes.LORE, new LoreComponent(List.of(
                Text.literal(r.label).styled(st -> st.withItalic(false).withColor(r.color)),
                Text.literal("Оружие класса: " + c.displayName).styled(st -> st.withItalic(false).withColor(0x888888)),
                Text.literal("ПКМ — способность, Shift+ПКМ — смена").styled(st -> st.withItalic(false).withColor(0x888888)))));
        double dmg = 3 + 2.0 * r.ordinal();
        s.set(DataComponentTypes.ATTRIBUTE_MODIFIERS, AttributeModifiersComponent.builder()
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE,
                        new EntityAttributeModifier(Identifier.of(ArcanaMod.MOD_ID, "weapon_damage"), dmg, EntityAttributeModifier.Operation.ADD_VALUE),
                        AttributeModifierSlot.MAINHAND)
                .add(EntityAttributes.GENERIC_ATTACK_SPEED,
                        new EntityAttributeModifier(Identifier.of(ArcanaMod.MOD_ID, "weapon_speed"), -2.4, EntityAttributeModifier.Operation.ADD_VALUE),
                        AttributeModifierSlot.MAINHAND)
                .build());
    }

    public static int rarityOf(ItemStack s) {
        NbtComponent c = s.get(DataComponentTypes.CUSTOM_DATA);
        return c == null ? 0 : c.copyNbt().getInt("rarity");
    }

    /** Бонус к силе способностей, если в руке оружие своего класса. */
    public static double powerBonus(ServerPlayerEntity p) {
        ItemStack s = p.getMainHandStack();
        if (s.getItem() instanceof ClassWeaponItem w && w.weaponClass == CastManager.cls(p))
            return 0.04 * (rarityOf(s) + 1);
        return 0;
    }
}
