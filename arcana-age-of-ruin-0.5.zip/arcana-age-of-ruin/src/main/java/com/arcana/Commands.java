package com.arcana;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.command.CommandSource;
import net.minecraft.item.ItemStack;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;

import java.util.Arrays;

public final class Commands {
    private static LiteralArgumentBuilder<ServerCommandSource> op(String name) {
        return CommandManager.literal(name).requires(s -> s.hasPermissionLevel(2));
    }

    public static void register(CommandDispatcher<ServerCommandSource> d) {
        d.register(CommandManager.literal("arcana")
            .then(CommandManager.literal("class")
                .then(CommandManager.argument("name", StringArgumentType.word())
                    .suggests((ctx, b) -> CommandSource.suggestMatching(Arrays.stream(ArcanaClass.values()).map(c -> c.id), b))
                    .executes(Commands::setClass)))
            .then(CommandManager.literal("info").executes(Commands::info))
            .then(CommandManager.literal("stats").executes(ctx -> msg(ctx, Progression.sheet(ctx.getSource().getPlayerOrThrow()))))
            .then(CommandManager.literal("focus").executes(ctx -> { give(ctx, new ItemStack(ModItems.FOCUS)); return 1; }))
            .then(CommandManager.literal("weapon")
                .executes(ctx -> weapon(ctx, 0))
                .then(op("rarity").then(CommandManager.argument("r", IntegerArgumentType.integer(0, 6))
                    .executes(ctx -> weapon(ctx, IntegerArgumentType.getInteger(ctx, "r"))))))
            .then(CommandManager.literal("skill")
                .then(CommandManager.argument("name", StringArgumentType.word())
                    .suggests((ctx, b) -> CommandSource.suggestMatching(java.util.stream.Stream.of("power", "mana", "vitality", "regen"), b))
                    .executes(ctx -> {
                        String err = Progression.spendSkill(ctx.getSource().getPlayerOrThrow(), StringArgumentType.getString(ctx, "name"));
                        return err == null ? msg(ctx, "§aНавык улучшен.") : fail(ctx, err);
                    })))
            .then(CommandManager.literal("spec")
                .then(CommandManager.argument("name", StringArgumentType.word())
                    .suggests((ctx, b) -> CommandSource.suggestMatching(java.util.stream.Stream.of("power", "focus", "haste"), b))
                    .executes(ctx -> {
                        String err = Progression.chooseSpec(ctx.getSource().getPlayerOrThrow(), StringArgumentType.getString(ctx, "name"));
                        return err == null ? msg(ctx, "§aСпециализация выбрана.") : fail(ctx, err);
                    })))
            .then(op("trial").executes(Commands::trial))
            .then(CommandManager.literal("top")
                .executes(ctx -> msg(ctx, Guilds.top(false)))
                .then(CommandManager.literal("guilds").executes(ctx -> msg(ctx, Guilds.top(true)))))
            .then(CommandManager.literal("guild")
                .then(CommandManager.literal("create").then(CommandManager.argument("name", StringArgumentType.word()).executes(ctx -> gres(ctx, Guilds.create(ctx.getSource().getPlayerOrThrow(), StringArgumentType.getString(ctx, "name"))))))
                .then(CommandManager.literal("invite").then(CommandManager.argument("player", StringArgumentType.word()).executes(ctx -> gres(ctx, Guilds.invite(ctx.getSource().getPlayerOrThrow(), StringArgumentType.getString(ctx, "player"))))))
                .then(CommandManager.literal("kick").then(CommandManager.argument("player", StringArgumentType.word()).executes(ctx -> gres(ctx, Guilds.kick(ctx.getSource().getPlayerOrThrow(), StringArgumentType.getString(ctx, "player"))))))
                .then(CommandManager.literal("accept").executes(ctx -> gres(ctx, Guilds.accept(ctx.getSource().getPlayerOrThrow()))))
                .then(CommandManager.literal("leave").executes(ctx -> gres(ctx, Guilds.leave(ctx.getSource().getPlayerOrThrow()))))
                .then(CommandManager.literal("disband").executes(ctx -> gres(ctx, Guilds.disband(ctx.getSource().getPlayerOrThrow()))))
                .then(CommandManager.literal("info").executes(ctx -> gres(ctx, Guilds.info(ctx.getSource().getPlayerOrThrow()))))
                .then(CommandManager.literal("quests").executes(ctx -> gres(ctx, Guilds.quests(ctx.getSource().getPlayerOrThrow()))))
                .then(CommandManager.literal("chat").then(CommandManager.argument("msg", StringArgumentType.greedyString()).executes(ctx -> {
                    Guilds.chat(ctx.getSource().getPlayerOrThrow(), StringArgumentType.getString(ctx, "msg"));
                    return 1;
                }))))
            .then(CommandManager.literal("pet")
                .then(CommandManager.literal("list").executes(ctx -> msg(ctx, Pets.list(ctx.getSource().getPlayerOrThrow()))))
                .then(CommandManager.literal("call").then(CommandManager.argument("n", IntegerArgumentType.integer(1, Pets.MAX_PETS)).executes(ctx -> {
                    String err = Pets.call(ctx.getSource().getPlayerOrThrow(), IntegerArgumentType.getInteger(ctx, "n") - 1);
                    return err == null ? 1 : fail(ctx, err);
                })))
                .then(CommandManager.literal("rest").executes(ctx -> { Pets.rest(ctx.getSource().getPlayerOrThrow()); return 1; }))
                .then(CommandManager.literal("feed").executes(ctx -> {
                    String err = Pets.feed(ctx.getSource().getPlayerOrThrow());
                    return err == null ? 1 : fail(ctx, err);
                }))
                .then(op("give").then(CommandManager.argument("species", StringArgumentType.word())
                    .suggests((ctx, b) -> CommandSource.suggestMatching(Pets.SPECIES.keySet().stream(), b))
                    .executes(ctx -> {
                        String sp = StringArgumentType.getString(ctx, "species");
                        if (!Pets.SPECIES.containsKey(sp)) return fail(ctx, "Виды: " + String.join(", ", Pets.SPECIES.keySet()));
                        give(ctx, Pets.egg(sp));
                        return 1;
                    }))))
            .then(CommandManager.literal("artifact")
                .then(CommandManager.literal("list").executes(ctx -> msg(ctx, Artifacts.list(ctx.getSource().getPlayerOrThrow()))))
                .then(CommandManager.literal("remove").then(CommandManager.argument("n", IntegerArgumentType.integer(1, Artifacts.SLOTS)).executes(ctx -> {
                    String err = Artifacts.remove(ctx.getSource().getPlayerOrThrow(), IntegerArgumentType.getInteger(ctx, "n") - 1);
                    return err == null ? 1 : fail(ctx, err);
                })))
                .then(op("give").then(CommandManager.argument("id", StringArgumentType.word())
                    .suggests((ctx, b) -> CommandSource.suggestMatching(Artifacts.ALL.keySet().stream(), b))
                    .then(CommandManager.argument("tier", IntegerArgumentType.integer(0, 6)).executes(ctx -> {
                        String id = StringArgumentType.getString(ctx, "id");
                        if (!Artifacts.ALL.containsKey(id)) return fail(ctx, "Нет такого артефакта.");
                        give(ctx, Artifacts.create(id, IntegerArgumentType.getInteger(ctx, "tier")));
                        return 1;
                    })))))
            .then(CommandManager.literal("travel").executes(ctx -> {
                String err = RuinsWorld.travel(ctx.getSource().getPlayerOrThrow());
                return err == null ? 1 : fail(ctx, err);
            }))
            .then(CommandManager.literal("home").executes(ctx -> {
                String err = RuinsWorld.home(ctx.getSource().getPlayerOrThrow());
                return err == null ? 1 : fail(ctx, err);
            }))
            .then(CommandManager.literal("biome").executes(ctx -> msg(ctx, RuinsWorld.describe(ctx.getSource().getPlayerOrThrow()))))
            .then(CommandManager.literal("forge")
                .executes(ctx -> {
                    ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                    String err = Forge.upgrade(p);
                    if (err != null) return fail(ctx, err);
                    return msg(ctx, "§6Оружие перекованo: " + Rarity.of(Weapons.rarityOf(p.getMainHandStack())).label);
                })
                .then(CommandManager.literal("cost").executes(ctx -> {
                    ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                    int r = Weapons.rarityOf(p.getMainHandStack());
                    return msg(ctx, r >= 6 ? "Максимальная редкость." : "До «" + Rarity.of(r + 1).label + "»: " + Forge.costText(r + 1));
                })))
            .then(CommandManager.literal("awaken").executes(ctx -> {
                String err = Progression.awaken(ctx.getSource().getPlayerOrThrow());
                return err == null ? 1 : fail(ctx, err);
            }))
            .then(op("setlevel").then(CommandManager.argument("n", IntegerArgumentType.integer(1, Progression.MAX_LEVEL)).executes(ctx -> {
                ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                PlayerData pd = CastManager.data(p);
                int n = IntegerArgumentType.getInteger(ctx, "n");
                CastManager.save(p, pd.withProgress(n, 0, pd.points() + Math.max(0, n - pd.level())));
                Progression.applyStats(p);
                return msg(ctx, "Уровень: " + n);
            })))
            .then(CommandManager.literal("boss")
                .then(CommandManager.literal("list").executes(ctx -> msg(ctx, "Боссы: " + String.join(", ", Bosses.DEFS.keySet()))))
                .then(op("spawn").then(CommandManager.argument("id", StringArgumentType.word())
                    .suggests((ctx, b) -> CommandSource.suggestMatching(Bosses.DEFS.keySet().stream(), b))
                    .executes(Commands::spawnBoss))))
            .then(CommandManager.literal("event")
                .then(op("start").executes(ctx -> startEvent(ctx, FallOfCreation.DEFAULT_COUNTDOWN_TICKS))
                    .then(CommandManager.argument("minutes", IntegerArgumentType.integer(0, 10000))
                        .executes(ctx -> startEvent(ctx, IntegerArgumentType.getInteger(ctx, "minutes") * 1200L))))
                .then(op("stop").executes(ctx -> { FallOfCreation.stop(ctx.getSource().getServer()); return 1; }))
                .then(op("skip").executes(ctx -> { FallOfCreation.skip(ctx.getSource().getServer()); return 1; }))
                .then(CommandManager.literal("status").executes(ctx -> msg(ctx, FallOfCreation.status(ctx.getSource().getServer()))))
                .then(CommandManager.literal("join").executes(ctx -> { FallOfCreation.join(ctx.getSource().getPlayerOrThrow()); return msg(ctx, "Вы участвуете в ивенте."); }))
                .then(CommandManager.literal("restore").executes(ctx -> {
                    String err = FallOfCreation.restore(ctx.getSource().getPlayerOrThrow());
                    return err == null ? 1 : fail(ctx, err);
                }))));
    }

    private static int gres(CommandContext<ServerCommandSource> ctx, String r) {
        return r.startsWith("!") ? fail(ctx, r.substring(1)) : msg(ctx, r);
    }

    private static int msg(CommandContext<ServerCommandSource> ctx, String s) {
        ctx.getSource().sendFeedback(() -> Text.literal(s), false);
        return 1;
    }
    private static int fail(CommandContext<ServerCommandSource> ctx, String s) {
        ctx.getSource().sendError(Text.literal(s));
        return 0;
    }
    private static void give(CommandContext<ServerCommandSource> ctx, ItemStack st) throws CommandSyntaxException {
        ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
        if (!p.giveItemStack(st)) p.dropItem(st, false);
    }

    private static int setClass(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
        ArcanaClass c = ArcanaClass.byId(StringArgumentType.getString(ctx, "name"));
        if (c == null) return fail(ctx, "Нет такого класса. Доступно: " + String.join(", ", Arrays.stream(ArcanaClass.values()).map(x -> x.id).toList()));
        CastManager.setClass(p, c);
        return msg(ctx, "§6Класс: " + c.displayName + " — " + c.title
                + "\n§7Возьми /arcana focus или /arcana weapon. ПКМ — каст, Shift+ПКМ — смена способности. /arcana stats — прокачка.");
    }

    private static int info(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
        ArcanaClass c = CastManager.cls(p);
        if (c == null) return msg(ctx, "Класс не выбран: /arcana class <" + String.join("|", Arrays.stream(ArcanaClass.values()).map(x -> x.id).toList()) + ">");
        PlayerData pd = CastManager.data(p);
        StringBuilder sb = new StringBuilder("§6" + c.displayName + " — " + c.title + "\n§7Пассивка: " + c.passive);
        for (int i = 0; i < c.abilities.size(); i++) {
            Ability a = c.abilities.get(i);
            boolean locked = pd.level() < Progression.SLOT_UNLOCK[i];
            sb.append("\n").append(i == pd.selected() ? "§e▶ " : "§f  ").append(i + 1).append(". ")
              .append(locked ? "§8" : "").append(a.name()).append(a.ultimate() ? " §6★" : "")
              .append(" §7— ").append(a.desc())
              .append(" §8[КД ").append(a.cooldownSec()).append("с, ").append(a.manaCost()).append(" маны")
              .append(locked ? ", ур. " + Progression.SLOT_UNLOCK[i] : "").append("]");
        }
        return msg(ctx, sb.toString());
    }

    private static int weapon(CommandContext<ServerCommandSource> ctx, int r) throws CommandSyntaxException {
        ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
        ArcanaClass c = CastManager.cls(p);
        if (c == null) return fail(ctx, "Сначала выбери класс.");
        give(ctx, Weapons.create(c, Rarity.of(r)));
        return 1;
    }

    private static int trial(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
        PlayerData pd = CastManager.data(p);
        if (CastManager.cls(p) == null) return fail(ctx, "Сначала выбери класс.");
        if (pd.level() < Progression.TRIAL_LEVEL) return fail(ctx, "Испытание доступно с уровня " + Progression.TRIAL_LEVEL + ".");
        if (pd.trial()) return fail(ctx, "Испытание уже пройдено.");
        Vec3d pos = Fx.aimPoint(p, 10);
        Bosses.spawn(Bosses.DEFS.get("trial"), p.getServerWorld(), pos, 1.0 + pd.level() / 50.0);
        return 1;
    }

    private static int spawnBoss(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
        Bosses.Def def = Bosses.DEFS.get(StringArgumentType.getString(ctx, "id"));
        if (def == null) return fail(ctx, "Нет такого босса. /arcana boss list");
        Bosses.spawn(def, p.getServerWorld(), Fx.aimPoint(p, 12), 1.0);
        return 1;
    }

    private static int startEvent(CommandContext<ServerCommandSource> ctx, long ticks) {
        FallOfCreation.start(ctx.getSource().getServer(), ticks);
        return 1;
    }
}
