package com.arcana;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.CustomModelDataComponent;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.random.Random;

import java.util.*;

/** Питомцы: яйца, уровни (до 30), эволюция на 10 и 25 уровне, ауры для хозяина. */
public final class Pets {
    public record Species(String id, String[] names, EntityType<? extends MobEntity> type, double scale,
                          double hp, double dmg, RegistryEntry<StatusEffect> aura, int weight, String auraText) {}

    public static final Map<String, Species> SPECIES = new LinkedHashMap<>();
    private static void sp(String id, String[] names, EntityType<? extends MobEntity> t, double scale, double hp, double dmg,
                           RegistryEntry<StatusEffect> aura, int weight, String auraText) {
        SPECIES.put(id, new Species(id, names, t, scale, hp, dmg, aura, weight, auraText));
    }
    static {
        sp("wolf", new String[]{"Теневой волк", "Лунный волк", "Фенрир"}, EntityType.WOLF, 1.0, 24, 5, StatusEffects.SPEED, 30, "Скорость");
        sp("fox", new String[]{"Дух лисы", "Лис-призрак", "Девятихвостый"}, EntityType.FOX, 1.0, 20, 4, StatusEffects.NIGHT_VISION, 25, "Ночное зрение");
        sp("ember", new String[]{"Искра", "Огненный дух", "Феникс"}, EntityType.BLAZE, 0.7, 28, 6, StatusEffects.FIRE_RESISTANCE, 20, "Огнеупорность");
        sp("golem", new String[]{"Каменный малыш", "Каменный страж", "Колосс"}, EntityType.IRON_GOLEM, 0.5, 60, 10, StatusEffects.ABSORPTION, 15, "Поглощение");
        sp("wisp", new String[]{"Ветерок", "Дух ветра", "Бог бури"}, EntityType.VEX, 1.0, 20, 5, StatusEffects.SLOW_FALLING, 10, "Плавное падение");
    }

    public static final int MAX_LEVEL = 30, MAX_PETS = 8;
    private static final double[] STAGE_MULT = {1.0, 1.5, 2.5};
    private static final double[] SCALE_MULT = {1.0, 1.4, 2.0};
    private static final Map<UUID, MobEntity> ACTIVE = new HashMap<>();
    private static final Map<UUID, Long> FAINT = new HashMap<>();
    private static final long FAINT_TICKS = 6000;

    public static int stage(int level) { return level >= 25 ? 3 : level >= 10 ? 2 : 1; }
    public static int xpNeed(int level) { return 50 + 30 * level; }

    public static PetsData data(ServerPlayerEntity p) { return p.getAttachedOrCreate(ArcanaMod.PETS); }
    private static void save(ServerPlayerEntity p, PetsData d) { p.setAttached(ArcanaMod.PETS, d); }

    // ───────────── яйца ─────────────
    public static ItemStack egg(String species) {
        Species s = SPECIES.get(species);
        ItemStack st = new ItemStack(ModItems.PET_EGG);
        NbtCompound n = new NbtCompound();
        n.putString("species", species);
        st.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(n));
        st.set(DataComponentTypes.CUSTOM_MODEL_DATA, new CustomModelDataComponent(new ArrayList<>(SPECIES.keySet()).indexOf(species) + 1));
        st.set(DataComponentTypes.CUSTOM_NAME, Text.literal("Яйцо: " + s.names()[0]).styled(x -> x.withItalic(false).withColor(0x55FFAA)));
        st.set(DataComponentTypes.LORE, new LoreComponent(List.of(
                Text.literal("ПКМ — вылупить питомца").styled(x -> x.withItalic(false).withColor(0x888888)),
                Text.literal("Аура: " + s.auraText()).styled(x -> x.withItalic(false).withColor(0x888888)))));
        return st;
    }

    public static ItemStack randomEgg(Random rnd) {
        int total = 0;
        for (Species s : SPECIES.values()) total += s.weight();
        int r = rnd.nextInt(total);
        for (Species s : SPECIES.values()) { r -= s.weight(); if (r < 0) return egg(s.id()); }
        return egg("wolf");
    }

    public static String hatch(ServerPlayerEntity p, String species) {
        if (!SPECIES.containsKey(species)) return "Это пустое яйцо.";
        PetsData d = data(p);
        if (d.pets().size() >= MAX_PETS) return "У тебя уже " + MAX_PETS + " питомцев.";
        List<PetsData.Pet> l = new ArrayList<>(d.pets());
        l.add(new PetsData.Pet(species, 1, 0, ""));
        save(p, new PetsData(l, d.active()));
        p.sendMessage(Text.literal("§aВылупился питомец: §f" + SPECIES.get(species).names()[0] + " §7(/arcana pet call " + l.size() + ")"), false);
        Fx.puff(p.getServerWorld(), ParticleTypes.HAPPY_VILLAGER, p.getPos().add(0, 1, 0), 30, 0.5, 0.1);
        return null;
    }

    // ───────────── вызов ─────────────
    private static void setBase(MobEntity m, RegistryEntry<EntityAttribute> a, double v) {
        EntityAttributeInstance i = m.getAttributeInstance(a);
        if (i != null) i.setBaseValue(v);
    }

    private static void apply(MobEntity m, Species sp, PetsData.Pet pet) {
        int st = stage(pet.level());
        double hp = sp.hp() * (1 + 0.12 * pet.level()) * STAGE_MULT[st - 1];
        setBase(m, EntityAttributes.GENERIC_MAX_HEALTH, hp);
        m.setHealth((float) hp);
        setBase(m, EntityAttributes.GENERIC_ATTACK_DAMAGE, sp.dmg() * (1 + 0.08 * pet.level()) * STAGE_MULT[st - 1]);
        setBase(m, EntityAttributes.GENERIC_SCALE, sp.scale() * SCALE_MULT[st - 1]);
        String nm = pet.name().isEmpty() ? sp.names()[st - 1] : pet.name();
        m.setCustomName(Text.literal("§a" + nm + " §7Ур." + pet.level()));
    }

    public static String call(ServerPlayerEntity p, int idx) {
        PetsData d = data(p);
        if (idx < 0 || idx >= d.pets().size()) return "Нет питомца с таким номером. /arcana pet list";
        long now = p.getServer().getTicks();
        long until = FAINT.getOrDefault(p.getUuid(), 0L);
        if (until > now) return "Питомец без сил ещё " + ((until - now) / 20) + " с.";
        rest(p);
        PetsData.Pet pet = d.pets().get(idx);
        Species sp = SPECIES.get(pet.species());
        MobEntity m = Minions.spawn(p, sp.type(), "", 86400, 1.0, false);
        if (m == null) return "Не удалось призвать.";
        m.addCommandTag("arcana_pet");
        apply(m, sp, pet);
        ACTIVE.put(p.getUuid(), m);
        save(p, new PetsData(d.pets(), idx));
        return null;
    }

    public static void rest(ServerPlayerEntity p) {
        MobEntity m = ACTIVE.remove(p.getUuid());
        if (m != null) Minions.dismiss(m);
    }

    public static String list(ServerPlayerEntity p) {
        PetsData d = data(p);
        if (d.pets().isEmpty()) return "У тебя нет питомцев. Яйца падают с боссов.";
        StringBuilder sb = new StringBuilder("§6Питомцы:");
        for (int i = 0; i < d.pets().size(); i++) {
            PetsData.Pet pt = d.pets().get(i);
            Species sp = SPECIES.get(pt.species());
            int st = stage(pt.level());
            sb.append("\n").append(i == d.active() ? "§e▶ " : "§f  ").append(i + 1).append(". ").append(sp.names()[st - 1])
              .append(" §7ур. ").append(pt.level()).append(pt.level() < MAX_LEVEL ? " §8(" + pt.xp() + "/" + xpNeed(pt.level()) + ")" : " §8(макс.)")
              .append(" §7ступень ").append(st).append("/3, аура: ").append(sp.auraText());
        }
        return sb.toString();
    }

    // ───────────── опыт и эволюция ─────────────
    public static void addXp(ServerPlayerEntity p, int amount) {
        PetsData d = data(p);
        int ai = d.active();
        if (ai < 0 || ai >= d.pets().size() || !ACTIVE.containsKey(p.getUuid())) return;
        PetsData.Pet pet = d.pets().get(ai);
        if (pet.level() >= MAX_LEVEL) return;
        int lvl = pet.level(), xp = pet.xp() + amount, oldStage = stage(lvl);
        boolean up = false;
        while (lvl < MAX_LEVEL && xp >= xpNeed(lvl)) { xp -= xpNeed(lvl); lvl++; up = true; }
        if (lvl >= MAX_LEVEL) xp = 0;
        PetsData.Pet np = new PetsData.Pet(pet.species(), lvl, xp, pet.name());
        List<PetsData.Pet> l = new ArrayList<>(d.pets());
        l.set(ai, np);
        save(p, new PetsData(l, ai));
        if (!up) return;
        Species sp = SPECIES.get(pet.species());
        MobEntity m = ACTIVE.get(p.getUuid());
        if (m != null && m.isAlive()) apply(m, sp, np);
        p.sendMessage(Text.literal("§a" + sp.names()[stage(lvl) - 1] + " достиг уровня " + lvl + "!"), true);
        if (stage(lvl) > oldStage) {
            p.getServer().getPlayerManager().broadcast(Text.literal("§d✦ Питомец " + p.getName().getString() + " эволюционировал: §f" + sp.names()[stage(lvl) - 1]), false);
            if (m != null) Fx.puff(p.getServerWorld(), ParticleTypes.TOTEM_OF_UNDYING, m.getPos().add(0, 1, 0), 60, 0.8, 0.3);
            Fx.sound(p.getServerWorld(), p.getPos(), SoundEvents.ENTITY_PLAYER_LEVELUP, 0.6f);
        }
    }

    /** Подкормка: ресурс босса даёт 150 опыта активному питомцу. */
    public static String feed(ServerPlayerEntity p) {
        ItemStack s = p.getMainHandStack();
        boolean res = false;
        for (int i = 0; i < 11; i++) if (s.isOf(ModItems.RESOURCES.get(ModItems.RES[i][0]))) res = true;
        if (!res) return "Возьми в руку ресурс босса.";
        if (!ACTIVE.containsKey(p.getUuid())) return "Сначала призови питомца.";
        s.decrement(1);
        addXp(p, 150);
        return null;
    }

    // ───────────── тик и смерть ─────────────
    public static void tick(MinecraftServer s) {
        long now = s.getTicks();
        if (now % 20 != 0) return;
        Iterator<Map.Entry<UUID, MobEntity>> it = ACTIVE.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, MobEntity> e = it.next();
            MobEntity m = e.getValue();
            ServerPlayerEntity owner = s.getPlayerManager().getPlayer(e.getKey());
            if (m.isDead()) {
                FAINT.put(e.getKey(), now + FAINT_TICKS);
                if (owner != null) owner.sendMessage(Text.literal("§cПитомец потерял сознание и вернётся через 5 минут."), false);
                it.remove();
                continue;
            }
            if (m.isRemoved() || owner == null) { it.remove(); continue; }
            if (now % 100 == 0 && m.getWorld() == owner.getWorld() && m.squaredDistanceTo(owner) < 24 * 24) {
                PetsData d = data(owner);
                if (d.active() >= 0 && d.active() < d.pets().size()) {
                    PetsData.Pet pt = d.pets().get(d.active());
                    Fx.buff(owner, SPECIES.get(pt.species()).aura(), 8, Math.max(0, stage(pt.level()) - 1));
                }
            }
        }
    }

    public static boolean isPet(Entity e) { return e.getCommandTags().contains("arcana_pet"); }
}
