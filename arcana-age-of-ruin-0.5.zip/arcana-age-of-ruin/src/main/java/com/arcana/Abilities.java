package com.arcana;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * Способности 4 классов версии 0.1. Числа урона/КД взяты из описания.
 * Стоимость маны, длительности и ультимейты Фантома — рабочие значения (см. README).
 */
public final class Abilities {
    /** Игроки, у которых активно «Зеркало маны» (следующее заклинание копируется). */
    public static final Set<UUID> MIRROR = new HashSet<>();

    // ───────────── ДРАКОНОР ─────────────
    public static final List<Ability> DRAGONOR = List.of(
        new Ability("Драконий укус", "45 урона цели перед вами, поджигает", 12, 15, false, (p, w) -> {
            LivingEntity t = Fx.firstTarget(p, 5);
            if (t == null) return false;
            Fx.magic(t, p, 45f);
            t.setOnFireFor(3);
            Fx.puff(w, ParticleTypes.FLAME, Fx.center(t), 30, 0.4, 0.05);
            Fx.sound(w, t.getPos(), SoundEvents.ENTITY_PLAYER_ATTACK_STRONG, 0.7f);
            return true;
        }),
        new Ability("Пламенный взлёт", "подбрасывает врагов вокруг и вас, плавное падение", 25, 25, false, (p, w) -> {
            for (LivingEntity e : Fx.around(w, p.getPos(), 5, p)) {
                e.setVelocity(e.getVelocity().add(0, 1.0, 0));
                e.velocityModified = true;
            }
            p.setVelocity(p.getVelocity().add(0, 1.1, 0));
            p.velocityModified = true;
            p.fallDistance = 0;
            Fx.buff(p, StatusEffects.SLOW_FALLING, 6, 0);
            Fx.puff(w, ParticleTypes.FLAME, p.getPos(), 60, 1.2, 0.1);
            Fx.sound(w, p.getPos(), SoundEvents.ENTITY_BLAZE_SHOOT, 0.8f);
            return true;
        }),
        new Ability("Чешуя дракона", "~50% меньше урона на 8 сек (Сопротивление II)", 35, 20, false, (p, w) -> {
            Fx.buff(p, StatusEffects.RESISTANCE, 8, 1);
            Fx.puff(w, ParticleTypes.ASH, p.getPos().add(0, 1, 0), 40, 0.6, 0.02);
            Fx.sound(w, p.getPos(), SoundEvents.ITEM_ARMOR_EQUIP_NETHERITE.value(), 0.6f);
            return true;
        }),
        new Ability("Рёв древнего", "оглушает врагов в радиусе 8 блоков", 40, 25, false, (p, w) -> {
            for (LivingEntity e : Fx.around(w, p.getPos(), 8, p)) {
                Fx.buff(e, StatusEffects.SLOWNESS, 4, 3);
                Fx.buff(e, StatusEffects.WEAKNESS, 5, 1);
                Fx.buff(e, StatusEffects.GLOWING, 4, 0);
            }
            Fx.puff(w, ParticleTypes.SONIC_BOOM, p.getPos().add(0, 1.5, 0), 1, 0, 0);
            Fx.sound(w, p.getPos(), SoundEvents.ENTITY_ENDER_DRAGON_GROWL, 0.9f);
            return true;
        }),
        new Ability("Пробуждение дракона", "15 сек: Сила II, Скорость, огнеупорность (модель — позже)", 120, 80, true, (p, w) -> {
            Fx.buff(p, StatusEffects.STRENGTH, 15, 1);
            Fx.buff(p, StatusEffects.RESISTANCE, 15, 0);
            Fx.buff(p, StatusEffects.FIRE_RESISTANCE, 15, 0);
            Fx.buff(p, StatusEffects.SPEED, 15, 0);
            Fx.buff(p, StatusEffects.SLOW_FALLING, 15, 0);
            Fx.puff(w, ParticleTypes.DRAGON_BREATH, p.getPos().add(0, 1, 0), 120, 1.5, 0.05);
            Fx.sound(w, p.getPos(), SoundEvents.ENTITY_ENDER_DRAGON_GROWL, 0.6f);
            return true;
        })
    );

    // ───────────── АРКАНИСТ ─────────────
    public static final List<Ability> ARCANIST = List.of(
        new Ability("Разлом", "35 урона цели на дистанции до 20 блоков", 10, 15, false, (p, w) -> {
            LivingEntity t = Fx.firstTarget(p, 20);
            if (t == null) return false;
            Fx.beam(w, ParticleTypes.PORTAL, p.getEyePos().add(0, -0.2, 0), Fx.center(t));
            Fx.magic(t, p, 35f);
            Fx.puff(w, ParticleTypes.REVERSE_PORTAL, Fx.center(t), 40, 0.5, 0.2);
            Fx.sound(w, t.getPos(), SoundEvents.ENTITY_ENDERMAN_TELEPORT, 0.6f);
            return true;
        }),
        new Ability("Гравитационная сфера", "3 сек притягивает врагов к точке прицела", 25, 25, false, (p, w) -> {
            Vec3d c = Fx.aimPoint(p, 15);
            for (int i = 0; i < 12; i++) {
                Scheduler.later(w.getServer(), i * 5, () -> {
                    for (LivingEntity e : Fx.around(w, c, 8, p)) {
                        Vec3d pull = c.subtract(e.getPos()).normalize().multiply(0.4);
                        e.setVelocity(e.getVelocity().multiply(0.4).add(pull));
                        e.velocityModified = true;
                    }
                    Fx.puff(w, ParticleTypes.REVERSE_PORTAL, c, 25, 1.5, 0.1);
                });
            }
            Fx.sound(w, c, SoundEvents.BLOCK_BEACON_ACTIVATE, 0.6f);
            return true;
        }),
        new Ability("Зеркало маны", "следующее заклинание сработает дважды", 40, 20, false, (p, w) -> {
            MIRROR.add(p.getUuid());
            Fx.puff(w, ParticleTypes.ENCHANT, p.getPos().add(0, 1, 0), 60, 0.8, 0.5);
            Fx.sound(w, p.getPos(), SoundEvents.BLOCK_ENCHANTMENT_TABLE_USE, 1.2f);
            return true;
        }),
        new Ability("Хаотический луч", "60 урона всем на линии + случайный эффект", 30, 30, false, (p, w) -> {
            Vec3d end = Fx.aimPoint(p, 25);
            double range = Math.min(25, p.getEyePos().distanceTo(end));
            Fx.beam(w, ParticleTypes.END_ROD, p.getEyePos().add(0, -0.2, 0), end);
            for (LivingEntity t : Fx.along(p, range, 0.8)) {
                Fx.magic(t, p, 60f);
                switch (p.getRandom().nextInt(3)) {
                    case 0 -> t.setOnFireFor(4);
                    case 1 -> Fx.buff(t, StatusEffects.SLOWNESS, 4, 2);
                    default -> Fx.buff(t, StatusEffects.WEAKNESS, 5, 1);
                }
            }
            Fx.sound(w, p.getPos(), SoundEvents.ENTITY_ILLUSIONER_CAST_SPELL, 1.2f);
            return true;
        }),
        new Ability("Абсолютная магия", "удар 4 стихий (огонь, молния, лёд, взрыв) в точке прицела", 120, 80, true, (p, w) -> {
            Vec3d c = Fx.aimPoint(p, 25);
            for (LivingEntity e : Fx.around(w, c, 6, p)) {
                Fx.magic(e, p, 80f);
                e.setOnFireFor(5);
                Fx.buff(e, StatusEffects.SLOWNESS, 5, 2);
            }
            LightningEntity bolt = EntityType.LIGHTNING_BOLT.create(w);
            if (bolt != null) {
                bolt.refreshPositionAfterTeleport(c);
                bolt.setChanneler(p);
                w.spawnEntity(bolt);
            }
            Fx.puff(w, ParticleTypes.EXPLOSION_EMITTER, c, 1, 0, 0);
            Fx.puff(w, ParticleTypes.SNOWFLAKE, c, 150, 3, 0.2);
            Fx.sound(w, c, SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, 1f);
            return true;
        })
    );

    // ───────────── ФАНТОМ ─────────────
    // 3-я, 4-я способности и ультимейт на записи не уместились — значения придуманы мной.
    public static final List<Ability> PHANTOM = List.of(
        new Ability("Теневой скачок", "телепорт на 12 блоков", 8, 15, false, (p, w) -> {
            Vec3d eye = p.getEyePos();
            Vec3d dir = p.getRotationVec(1f);
            Vec3d end = eye.add(dir.multiply(12));
            HitResult hit = w.raycast(new RaycastContext(eye, end,
                    RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));
            Vec3d dest = hit.getType() == HitResult.Type.MISS ? end : hit.getPos();
            for (int i = 0; i < 8; i++) {
                Vec3d eyeTo = dest.subtract(dir.multiply(0.5 * i));
                Vec3d feet = eyeTo.subtract(0, p.getStandingEyeHeight(), 0);
                if (w.isSpaceEmpty(p, p.getBoundingBox().offset(feet.subtract(p.getPos())))) {
                    Fx.puff(w, ParticleTypes.PORTAL, p.getPos().add(0, 1, 0), 40, 0.4, 0.3);
                    p.requestTeleport(feet.x, feet.y, feet.z);
                    p.fallDistance = 0;
                    Fx.puff(w, ParticleTypes.PORTAL, feet.add(0, 1, 0), 40, 0.4, 0.3);
                    Fx.sound(w, feet, SoundEvents.ENTITY_ENDERMAN_TELEPORT, 1.2f);
                    return true;
                }
            }
            return false;
        }),
        new Ability("Копия смерти", "две иллюзии на 8 сек: отвлекают врагов и взрываются тенью (25 урона), вы невидимы 5 сек", 30, 25, false, (p, w) -> {
            Illusions.spawn(p, 2);
            Fx.buff(p, StatusEffects.INVISIBILITY, 5, 0);
            Fx.buff(p, StatusEffects.SPEED, 5, 1);
            Fx.puff(w, ParticleTypes.LARGE_SMOKE, p.getPos().add(0, 1, 0), 40, 0.5, 0.05);
            Fx.sound(w, p.getPos(), SoundEvents.ENTITY_ENDERMAN_TELEPORT, 0.7f);
            return true;
        }),
        new Ability("Удар из тени", "40 урона цели (60 со спины)", 12, 15, false, (p, w) -> {
            LivingEntity t = Fx.firstTarget(p, 4);
            if (t == null) return false;
            boolean behind = t.getRotationVec(1f).dotProduct(p.getRotationVec(1f)) > 0.3;
            Fx.magic(t, p, behind ? 60f : 40f);
            Fx.puff(w, behind ? ParticleTypes.CRIT : ParticleTypes.SMOKE, Fx.center(t), 25, 0.4, 0.2);
            Fx.sound(w, t.getPos(), SoundEvents.ENTITY_PLAYER_ATTACK_CRIT, 0.8f);
            return true;
        }),
        new Ability("Теневой покров", "8 сек невидимость", 35, 20, false, (p, w) -> {
            Fx.buff(p, StatusEffects.INVISIBILITY, 8, 0);
            Fx.puff(w, ParticleTypes.SMOKE, p.getPos().add(0, 1, 0), 40, 0.5, 0.02);
            return true;
        }),
        new Ability("Царство теней", "10 сек: вы невидимы и быстры, 3 иллюзии, враги в 10 блоках ослеплены", 120, 80, true, (p, w) -> {
            Fx.buff(p, StatusEffects.INVISIBILITY, 10, 0);
            Fx.buff(p, StatusEffects.SPEED, 10, 2);
            Fx.buff(p, StatusEffects.NIGHT_VISION, 10, 0);
            Illusions.spawn(p, 3);
            for (LivingEntity e : Fx.around(w, p.getPos(), 10, p)) {
                Fx.buff(e, StatusEffects.DARKNESS, 10, 0);
                Fx.buff(e, StatusEffects.BLINDNESS, 5, 0);
                Fx.buff(e, StatusEffects.SLOWNESS, 5, 1);
            }
            Fx.puff(w, ParticleTypes.SQUID_INK, p.getPos().add(0, 1, 0), 100, 3, 0.05);
            Fx.sound(w, p.getPos(), SoundEvents.ENTITY_WARDEN_SONIC_BOOM, 0.6f);
            return true;
        })
    );

    // ───────────── ТИТАН ─────────────
    public static final List<Ability> TITAN = List.of(
        new Ability("Удар колосса", "55 урона цели и подброс", 15, 20, false, (p, w) -> {
            LivingEntity t = Fx.firstTarget(p, 5);
            if (t == null) return false;
            Fx.magic(t, p, 55f);
            t.setVelocity(t.getVelocity().add(0, 0.7, 0));
            t.velocityModified = true;
            Fx.puff(w, ParticleTypes.EXPLOSION, Fx.center(t), 3, 0.5, 0);
            Fx.sound(w, t.getPos(), SoundEvents.BLOCK_ANVIL_LAND, 0.6f);
            return true;
        }),
        new Ability("Землетрясение", "волна вокруг вас: 15 урона и отброс в радиусе 6", 25, 25, false, (p, w) -> {
            for (LivingEntity e : Fx.around(w, p.getPos(), 6, p)) {
                Fx.magic(e, p, 15f);
                Vec3d off = e.getPos().subtract(p.getPos());
                Vec3d h = new Vec3d(off.x, 0, off.z).normalize().multiply(0.7);
                e.setVelocity(h.x, 0.8, h.z);
                e.velocityModified = true;
            }
            Fx.puff(w, ParticleTypes.CLOUD, p.getPos().add(0, 0.2, 0), 120, 3, 0.1);
            Fx.sound(w, p.getPos(), SoundEvents.BLOCK_ANVIL_LAND, 0.4f);
            return true;
        }),
        new Ability("Каменная оболочка", "8 сек сильное снижение урона (медленнее ходьба)", 40, 20, false, (p, w) -> {
            Fx.buff(p, StatusEffects.RESISTANCE, 8, 3);
            Fx.buff(p, StatusEffects.ABSORPTION, 8, 1);
            Fx.buff(p, StatusEffects.SLOWNESS, 8, 0);
            Fx.puff(w, ParticleTypes.ASH, p.getPos().add(0, 1, 0), 50, 0.6, 0.02);
            Fx.sound(w, p.getPos(), SoundEvents.BLOCK_STONE_PLACE, 0.5f);
            return true;
        }),
        new Ability("Вызов на бой", "мобы в радиусе 10 блоков переключаются на вас", 20, 15, false, (p, w) -> {
            int n = 0;
            for (LivingEntity e : Fx.around(w, p.getPos(), 10, p))
                if (e instanceof MobEntity m) { m.setTarget(p); n++; }
            if (n == 0) return false;
            Fx.puff(w, ParticleTypes.ANGRY_VILLAGER, p.getPos().add(0, 2, 0), 15, 0.6, 0);
            Fx.sound(w, p.getPos(), SoundEvents.ENTITY_RAVAGER_ROAR, 1f);
            return true;
        }),
        new Ability("Гнев титана", "12 сек: вы вырастаете в 1.5 раза, Сила II, Сопротивление II", 120, 80, true, (p, w) -> {
            EntityAttributeInstance inst = p.getAttributeInstance(EntityAttributes.GENERIC_SCALE);
            Identifier id = Identifier.of(ArcanaMod.MOD_ID, "titan_wrath");
            if (inst != null) {
                inst.removeModifier(id);
                inst.addTemporaryModifier(new EntityAttributeModifier(id, 0.5, EntityAttributeModifier.Operation.ADD_MULTIPLIED_BASE));
                Scheduler.later(w.getServer(), 240, () -> inst.removeModifier(id));
            }
            Fx.buff(p, StatusEffects.STRENGTH, 12, 1);
            Fx.buff(p, StatusEffects.RESISTANCE, 12, 1);
            Fx.puff(w, ParticleTypes.EXPLOSION, p.getPos().add(0, 1, 0), 6, 1, 0);
            Fx.sound(w, p.getPos(), SoundEvents.ENTITY_RAVAGER_ROAR, 0.6f);
            return true;
        })
    );
}
