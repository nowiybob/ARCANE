package com.arcana;

import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.Map;

/** Печать на арене (Плачущий обсидиан): вызывает босса этого биома. Перезарядка 5 минут. */
public final class Sigils {
    private static final Map<Long, Long> LAST = new HashMap<>();
    private static final long COOLDOWN = 6000;

    public static void use(ServerPlayerEntity p, BlockPos pos) {
        ServerWorld w = (ServerWorld) p.getWorld();
        BiomeInfo b = RuinsWorld.biomeAt(w, pos);
        if (b == null) return;
        Bosses.Def def = Bosses.DEFS.get(b.boss());
        long now = p.getServer().getTicks();
        Long last = LAST.get(pos.asLong());
        if (last != null && now - last < COOLDOWN) {
            p.sendMessage(Text.literal("§7Печать остывает: ещё " + ((COOLDOWN - (now - last)) / 20) + " с"), true);
            return;
        }
        if (Bosses.active().stream().anyMatch(x -> x.def.id().equals(def.id()))) {
            p.sendMessage(Text.literal("§7Этот босс уже призван."), true);
            return;
        }
        LAST.put(pos.asLong(), now);
        int players = w.getPlayers(x -> x.squaredDistanceTo(Vec3d.ofCenter(pos)) < 40 * 40).size();
        Bosses.spawn(def, w, Vec3d.ofBottomCenter(pos).add(0, 1, 5), 1.0 + 0.3 * Math.max(0, players - 1));
    }
}
