package com.arcana;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/** Оружие класса: ПКМ — каст (как у фокуса), удар — эффект класса от редкости «Необычное»+. */
public class ClassWeaponItem extends Item {
    public final ArcanaClass weaponClass;

    public ClassWeaponItem(Settings s, ArcanaClass c) { super(s); this.weaponClass = c; }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (!world.isClient && user instanceof ServerPlayerEntity sp) {
            if (sp.isSneaking()) CastManager.cycle(sp); else CastManager.cast(sp);
            sp.getItemCooldownManager().set(this, 4);
        }
        return TypedActionResult.success(stack, world.isClient());
    }

    @Override
    public void inventoryTick(ItemStack stack, World world, net.minecraft.entity.Entity entity, int slot, boolean selected) {
        if (!world.isClient && stack.get(net.minecraft.component.DataComponentTypes.CUSTOM_DATA) == null)
            Weapons.init(stack, weaponClass, Rarity.COMMON);
        super.inventoryTick(stack, world, entity, slot, selected);
    }

    @Override
    public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        int r = Weapons.rarityOf(stack);
        if (r >= 2) {
            switch (weaponClass) {
                case DRAGONOR, SOLARIS -> target.setOnFireFor(2 + r);
                case ARCANIST, CHRONOMAGE -> Fx.buff(target, StatusEffects.SLOWNESS, 2 + r, 1);
                case PHANTOM, NECROMANCER -> Fx.buff(target, StatusEffects.WEAKNESS, 2 + r, 0);
                case TITAN -> Fx.buff(target, StatusEffects.SLOWNESS, 1 + r, 2);
                case SUMMONER, DRUID -> Fx.buff(target, StatusEffects.POISON, 2 + r, 0);
                case STORMCALLER -> Fx.buff(target, StatusEffects.GLOWING, 3 + r, 0);
                case RANGER -> Fx.buff(target, StatusEffects.GLOWING, 5 + r, 0);
                case ALCHEMIST -> Fx.buff(target, StatusEffects.POISON, 2 + r, 1);
            }
        }
        if (r >= 4 && attacker instanceof ServerPlayerEntity sp) CastManager.addMana(sp, r - 3);
        return super.postHit(stack, target, attacker);
    }
}
