package com.arcana;

import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;

/** Одна способность класса. effect возвращает false, если каст не удался (нет цели) — тогда мана и КД не тратятся. */
public record Ability(String name, String desc, int cooldownSec, int manaCost, boolean ultimate, Effect effect) {
    @FunctionalInterface
    public interface Effect {
        boolean cast(ServerPlayerEntity player, ServerWorld world);
    }
}
