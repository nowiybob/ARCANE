package com.arcana;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.potion.Potion;
import net.minecraft.potion.Potions;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Мана, кулдауны, выбор и каст способностей, пассивки, зависящие от тика. */
public final class CastManager {
    private static final Map<UUID, long[]> COOLDOWNS = new HashMap<>();
    private static final Map<UUID, Long> SILENCE = new HashMap<>();
    private static final Map<UUID, ArrayDeque<Vec3d>> HISTORY = new HashMap<>();

    public static PlayerData data(ServerPlayerEntity p) { return p.getAttachedOrCreate(ArcanaMod.DATA); }
    public static void save(ServerPlayerEntity p, PlayerData d) { p.setAttached(ArcanaMod.DATA, d); }
    public static ArcanaClass cls(ServerPlayerEntity p) { return ArcanaClass.byId(data(p).cls()); }

    public static void setClass(ServerPlayerEntity p, ArcanaClass c) {
        PlayerData old = data(p);
        // при смене класса прогресс сохраняется
        save(p, new PlayerData(c.id, Progression.maxMana(p), 0, old.level(), old.xp(), old.points(),
                old.spec(), false, false, old.pw(), old.mn(), old.vt(), old.rg()));
        save(p, data(p).withMana(Progression.maxMana(p)));
        COOLDOWNS.remove(p.getUuid());
        Abilities.MIRROR.remove(p.getUuid());
        Progression.applyStats(p);
    }

    public static void addMana(ServerPlayerEntity p, double amount) {
        PlayerData d = data(p);
        save(p, d.withMana(Math.max(0, Math.min(Progression.maxMana(p), d.mana() + amount))));
    }

    public static void silence(ServerPlayerEntity p, int ticks) {
        SILENCE.put(p.getUuid(), p.getServer().getTicks() + (long) ticks);
    }

    public static Vec3d rewindPoint(ServerPlayerEntity p) {
        ArrayDeque<Vec3d> h = HISTORY.get(p.getUuid());
        return (h == null || h.size() < 3) ? null : h.peekFirst();
    }

    private static void bar(ServerPlayerEntity p, String msg) { p.sendMessage(Text.literal(msg), true); }

    public static void cycle(ServerPlayerEntity p) {
        ArcanaClass c = cls(p);
        if (c == null) { bar(p, "§cСначала выбери класс: /arcana class <имя>"); return; }
        PlayerData d = data(p);
        int lvl = d.level();
        int next = d.selected();
        for (int i = 0; i < c.abilities.size(); i++) {
            next = (next + 1) % c.abilities.size();
            if (lvl >= Progression.SLOT_UNLOCK[next]) break;
        }
        save(p, d.withSelected(next));
        bar(p, status(p));
    }

    public static void cast(ServerPlayerEntity p) {
        ArcanaClass c = cls(p);
        if (c == null) { bar(p, "§cСначала выбери класс: /arcana class <имя>"); return; }
        MinecraftServer server = p.getServer();
        if (server == null) return;

        PlayerData d = data(p);
        int sel = d.selected();
        Ability a = c.abilities.get(sel);
        long now = server.getTicks();

        if (d.level() < Progression.SLOT_UNLOCK[sel]) { bar(p, "§cСпособность откроется на уровне " + Progression.SLOT_UNLOCK[sel]); return; }
        if (SILENCE.getOrDefault(p.getUuid(), 0L) > now) { bar(p, "§5Магия подавлена!"); return; }
        long[] cd = COOLDOWNS.computeIfAbsent(p.getUuid(), k -> new long[8]);
        if (cd[sel] > now) { bar(p, "§c" + a.name() + ": перезарядка " + ((cd[sel] - now + 19) / 20) + " с"); return; }
        int cost = (int) Math.ceil(a.manaCost() * Progression.costMult(p));
        if (d.mana() < cost) { bar(p, "§9Не хватает маны (" + (int) d.mana() + "/" + cost + ")"); return; }

        boolean mirrored = Abilities.MIRROR.remove(p.getUuid());
        if (!a.effect().cast(p, p.getServerWorld())) {
            if (mirrored) Abilities.MIRROR.add(p.getUuid());
            bar(p, "§7" + a.name() + ": нет цели");
            return;
        }
        Guilds.onCast(p);
        PlayerData cur = data(p);
        save(p, cur.withMana(Math.max(0, cur.mana() - cost)));
        cd[sel] = now + (long) Math.ceil(a.cooldownSec() * 20 * Progression.cdMult(p, c));

        if (mirrored) {
            Scheduler.later(server, 10, () -> {
                if (p.isAlive() && !p.isRemoved()) a.effect().cast(p, p.getServerWorld());
            });
        }
        bar(p, status(p));
    }

    public static String status(ServerPlayerEntity p) {
        ArcanaClass c = cls(p);
        if (c == null) return "§7Класс не выбран";
        PlayerData d = data(p);
        Ability a = c.abilities.get(d.selected());
        return "§b✦ " + (int) d.mana() + "/" + (int) Progression.maxMana(p)
                + " §7| §e" + a.name() + (a.ultimate() ? " §6★" : "")
                + " §7(" + (d.selected() + 1) + "/" + c.abilities.size() + ", "
                + (int) Math.ceil(a.manaCost() * Progression.costMult(p)) + " маны) §8Ур." + d.level();
    }

    public static boolean holdsFocus(ServerPlayerEntity p) {
        ItemStack m = p.getMainHandStack(), o = p.getOffHandStack();
        return m.isOf(ModItems.FOCUS) || o.isOf(ModItems.FOCUS)
                || m.getItem() instanceof ClassWeaponItem || o.getItem() instanceof ClassWeaponItem;
    }

    private static final List<RegistryEntry<Potion>> POTIONS = List.of(
            Potions.HEALING, Potions.STRONG_SWIFTNESS, Potions.STRONG_STRENGTH, Potions.REGENERATION, Potions.INVISIBILITY);

    public static void tick(MinecraftServer server) {
        int t = server.getTicks();
        boolean hud = t % 10 == 0;
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            ArcanaClass c = cls(p);
            if (c == null) continue;
            PlayerData d = data(p);
            double max = Progression.maxMana(p);
            if (d.mana() < max) save(p, d.withMana(Math.min(max, d.mana() + Progression.regen(p, c) / 20.0)));

            // пассивки по тикам
            if (c == ArcanaClass.DRUID && t % 100 == 0 && p.getHealth() < p.getMaxHealth()) p.heal(1f);
            if (c == ArcanaClass.ALCHEMIST && t % 1200 == 0) {
                ItemStack potion = new ItemStack(Items.POTION);
                potion.set(DataComponentTypes.POTION_CONTENTS, new PotionContentsComponent(POTIONS.get(p.getRandom().nextInt(POTIONS.size()))));
                if (!p.giveItemStack(potion)) p.dropItem(potion, false);
                bar(p, "§aВы сварили зелье");
            }
            if (c == ArcanaClass.CHRONOMAGE && t % 10 == 0) {
                ArrayDeque<Vec3d> h = HISTORY.computeIfAbsent(p.getUuid(), k -> new ArrayDeque<>());
                h.addLast(p.getPos());
                while (h.size() > 10) h.pollFirst();
            }
            if (hud && holdsFocus(p)) bar(p, status(p));
        }
    }
}
