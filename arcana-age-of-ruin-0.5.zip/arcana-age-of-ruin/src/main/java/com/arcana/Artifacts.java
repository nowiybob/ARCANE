package com.arcana;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.CustomModelDataComponent;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.*;

/** Артефакты: ПКМ — надеть (до 3 слотов). Бонусы зависят от ступени (редкости 0–6). */
public final class Artifacts {
    public enum Kind { POWER, MANA, COOLDOWN, HEALTH, SPEED, FIRE, DODGE, SOULS, REGEN }

    public record Art(String id, String name, Kind kind, String boss) {}

    public static final Map<String, Art> ALL = new LinkedHashMap<>();
    private static void a(String id, String name, Kind k, String boss) { ALL.put(id, new Art(id, name, k, boss)); }
    static {
        a("glacier_amulet", "Сердце ледника", Kind.HEALTH, "verdax");
        a("ignis_scale", "Чешуя Игниса", Kind.FIRE, "ignis");
        a("seraph_feather", "Перо Серафима", Kind.COOLDOWN, "seraph");
        a("infinity_amulet", "Амулет Бесконечности", Kind.MANA, "abyss");
        a("treant_seed", "Семя Древня", Kind.REGEN, "treant");
        a("leviathan_current", "Течение Левиафана", Kind.SPEED, "leviathan");
        a("thunder_charm", "Оберег Грозы", Kind.POWER, "thorax");
        a("pharaoh_shroud", "Саван Фараона", Kind.DODGE, "pharaoh");
        a("spore_ring", "Споровое кольцо", Kind.HEALTH, "sporemother");
        a("colossus_shard", "Осколок колосса", Kind.MANA, "crystal");
        a("soul_crown", "Венец короля душ", Kind.SOULS, "malakhar");
        a("destroyer_heart", "Сердце Разрушителя", Kind.POWER, "god");
    }

    public static final int SLOTS = 3;

    public static double value(Kind k, int t) {
        return switch (k) {
            case POWER -> 0.03 * (t + 1);
            case MANA -> 10.0 * (t + 1);
            case COOLDOWN -> 0.03 * (t + 1);
            case HEALTH -> 2.0 * (t + 1);
            case SPEED -> 0.02 * (t + 1);
            case FIRE -> 1;
            case DODGE -> 0.04 * (t + 1);
            case SOULS -> 2.0 * (t + 1);
            case REGEN -> 0.3 * (t + 1);
        };
    }

    public static String text(Kind k, int t) {
        double v = value(k, t);
        return switch (k) {
            case POWER -> "+" + Math.round(v * 100) + "% к силе магии";
            case MANA -> "+" + (int) v + " к максимуму маны";
            case COOLDOWN -> "перезарядки короче на " + Math.round(v * 100) + "%";
            case HEALTH -> "+" + (int) v + " к максимуму здоровья";
            case SPEED -> "+" + Math.round(v * 100) + "% к скорости";
            case FIRE -> "иммунитет к огню";
            case DODGE -> Math.round(v * 100) + "% шанс уклониться от удара";
            case SOULS -> "+" + (int) v + " маны за убийство";
            case REGEN -> "+" + String.format("%.1f", v) + " маны в секунду";
        };
    }

    public static ArtData data(ServerPlayerEntity p) { return p.getAttachedOrCreate(ArcanaMod.ARTS); }

    public static double sum(ServerPlayerEntity p, Kind k) {
        double s = 0;
        for (ArtData.Entry e : data(p).list()) {
            Art a = ALL.get(e.id());
            if (a != null && a.kind() == k) s += value(k, e.tier());
        }
        return s;
    }

    public static ItemStack create(String id, int tier) {
        Art art = ALL.get(id);
        Rarity r = Rarity.of(tier);
        ItemStack st = new ItemStack(ModItems.ARTIFACT);
        NbtCompound n = new NbtCompound();
        n.putString("id", id);
        n.putInt("tier", tier);
        st.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(n));
        st.set(DataComponentTypes.CUSTOM_MODEL_DATA, new CustomModelDataComponent(new ArrayList<>(ALL.keySet()).indexOf(id) + 1));
        st.set(DataComponentTypes.CUSTOM_NAME, Text.literal(art.name()).styled(x -> x.withItalic(false).withColor(r.color)));
        st.set(DataComponentTypes.LORE, new LoreComponent(List.of(
                Text.literal(r.label + " артефакт").styled(x -> x.withItalic(false).withColor(r.color)),
                Text.literal(text(art.kind(), tier)).styled(x -> x.withItalic(false).withColor(0xFFFFFF)),
                Text.literal("ПКМ — надеть (до " + SLOTS + " артефактов)").styled(x -> x.withItalic(false).withColor(0x888888)))));
        return st;
    }

    public static ItemStack random(Random rnd, int maxTier) {
        List<Art> l = new ArrayList<>(ALL.values());
        l.removeIf(x -> x.boss().equals("god"));
        return create(l.get(rnd.nextInt(l.size())).id(), rnd.nextInt(maxTier + 1));
    }

    public static ItemStack forBoss(String bossId, int tier) {
        for (Art a : ALL.values()) if (a.boss().equals(bossId)) return create(a.id(), tier);
        return null;
    }

    public static String equip(ServerPlayerEntity p, ItemStack stack) {
        NbtComponent c = stack.get(DataComponentTypes.CUSTOM_DATA);
        if (c == null) return "Это пустой артефакт.";
        NbtCompound n = c.copyNbt();
        String id = n.getString("id");
        int tier = n.getInt("tier");
        if (!ALL.containsKey(id)) return "Неизвестный артефакт.";
        ArtData d = data(p);
        if (d.list().size() >= SLOTS) return "Все " + SLOTS + " слота заняты. Сними: /arcana artifact remove <номер>";
        for (ArtData.Entry e : d.list()) if (e.id().equals(id)) return "Такой артефакт уже надет.";
        List<ArtData.Entry> l = new ArrayList<>(d.list());
        l.add(new ArtData.Entry(id, tier));
        p.setAttached(ArcanaMod.ARTS, new ArtData(l));
        stack.decrement(1);
        Progression.applyStats(p);
        return null;
    }

    public static String remove(ServerPlayerEntity p, int idx) {
        ArtData d = data(p);
        if (idx < 0 || idx >= d.list().size()) return "Нет артефакта с таким номером.";
        List<ArtData.Entry> l = new ArrayList<>(d.list());
        ArtData.Entry e = l.remove(idx);
        p.setAttached(ArcanaMod.ARTS, new ArtData(l));
        ItemStack st = create(e.id(), e.tier());
        if (!p.giveItemStack(st)) p.dropItem(st, false);
        Progression.applyStats(p);
        return null;
    }

    public static String list(ServerPlayerEntity p) {
        ArtData d = data(p);
        if (d.list().isEmpty()) return "Артефакты не надеты. Они падают с боссов и лежат в подземельях.";
        StringBuilder sb = new StringBuilder("§6Артефакты (" + d.list().size() + "/" + SLOTS + "):");
        for (int i = 0; i < d.list().size(); i++) {
            ArtData.Entry e = d.list().get(i);
            Art a = ALL.get(e.id());
            sb.append("\n§f").append(i + 1).append(". ").append(a.name()).append(" §7[").append(Rarity.of(e.tier()).label)
              .append("] — ").append(text(a.kind(), e.tier()));
        }
        return sb.toString();
    }

    public static void tick(MinecraftServer s) {
        if (s.getTicks() % 5 != 0) return;
        for (ServerPlayerEntity p : s.getPlayerManager().getPlayerList())
            if (p.isOnFire() && sum(p, Kind.FIRE) > 0) p.extinguish();
    }
}
