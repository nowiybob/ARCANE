package com.arcana;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

public class ArtifactItem extends Item {
    public ArtifactItem(Settings s) { super(s); }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (!world.isClient && user instanceof ServerPlayerEntity sp) {
            String err = Artifacts.equip(sp, stack);
            sp.sendMessage(Text.literal(err == null ? "§aАртефакт надет. /arcana artifact list" : "§c" + err), true);
        }
        return TypedActionResult.success(stack, world.isClient());
    }
}
