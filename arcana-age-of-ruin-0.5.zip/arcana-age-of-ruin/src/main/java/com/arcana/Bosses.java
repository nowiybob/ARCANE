package com.arcana;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;

import java.util.*;
import java.util.function.Consumer;

/**
 * Боссы с «виртуальным» здоровьем (у ванильных мобов HP ограничен 1024):
 * мобу возвращается полное здоровье после каждого удара, а настоящее HP считаем сами.
 */
public final class Bosses {
    public enum Atk { ICE_NOVA, LAVA_WAVE, METEORS, SKY_SPEARS, BLACK_HOLE, SUMMON, SPORE_CLOUD, LIGHTNING,
        SAND_STORM, CRYSTAL_SPIKES, SOUL_DRAIN, ROOTS, TIDAL, QUAKE }

    public record Def(String id, String name, EntityType<? extends MobEntity> type, double scale, double hp,
                      BossBar.Color color, String drop, int rarity, float dmg, List<Atk> attacks) {}

    public static final Map<String, Def> DEFS = new LinkedHashMap<>();
    private static void def(String id, String name, EntityType<? extends MobEntity> t, double scale, double hp,
                            BossBar.Color c, String drop, int rarity, float dmg, Atk... a) {
        DEFS.put(id, new Def(id, name, t, scale, hp, c, drop, rarity, dmg, List.of(a)));
    }
    static {
        // HP первых четырёх — из описания; остальное подобрано мной
        def("verdax", "Вердакс — Ледяной пожиратель", EntityType.STRAY, 3.0, 12000, BossBar.Color.WHITE, "glacier_heart", 3, 6f, Atk.ICE_NOVA, Atk.SUMMON, Atk.QUAKE);
        def("ignis", "Игнис — Владыка пламени", EntityType.BLAZE, 3.0, 18000, BossBar.Color.RED, "flame_core", 3, 8f, Atk.LAVA_WAVE, Atk.METEORS, Atk.SUMMON);
        def("seraph", "Серафим — Падший небесный", EntityType.EVOKER, 2.5, 25000, BossBar.Color.YELLOW, "eternity_feather", 4, 10f, Atk.SKY_SPEARS, Atk.LIGHTNING, Atk.SUMMON);
        def("abyss", "Абисс — Пожиратель звёзд", EntityType.ENDERMAN, 3.5, 40000, BossBar.Color.PURPLE, "infinity_shard", 5, 12f, Atk.BLACK_HOLE, Atk.SOUL_DRAIN, Atk.METEORS);
        def("treant", "Древень", EntityType.RAVAGER, 1.6, 8000, BossBar.Color.GREEN, "eternal_life_seed", 2, 5f, Atk.ROOTS, Atk.SPORE_CLOUD, Atk.SUMMON);
        def("leviathan", "Левиафан", EntityType.DROWNED, 3.0, 14000, BossBar.Color.BLUE, "ocean_heart", 3, 7f, Atk.TIDAL, Atk.ICE_NOVA, Atk.SUMMON);
        def("thorax", "Торакс", EntityType.ILLUSIONER, 2.5, 16000, BossBar.Color.BLUE, "thunder_core", 3, 8f, Atk.LIGHTNING, Atk.SKY_SPEARS, Atk.QUAKE);
        def("pharaoh", "Фараон забытого времени", EntityType.HUSK, 3.0, 20000, BossBar.Color.YELLOW, "eternity_sand", 4, 9f, Atk.SAND_STORM, Atk.SUMMON, Atk.QUAKE);
        def("sporemother", "Мать спор", EntityType.SPIDER, 4.0, 15000, BossBar.Color.GREEN, "spore_heart", 3, 7f, Atk.SPORE_CLOUD, Atk.SUMMON, Atk.ROOTS);
        def("crystal", "Кристальный колосс", EntityType.IRON_GOLEM, 3.0, 30000, BossBar.Color.PINK, "pure_crystal", 4, 10f, Atk.CRYSTAL_SPIKES, Atk.QUAKE, Atk.SKY_SPEARS);
        def("malakhar", "Малахар — король мёртвых", EntityType.WITHER_SKELETON, 3.0, 35000, BossBar.Color.PURPLE, "king_soul", 5, 11f, Atk.SOUL_DRAIN, Atk.SUMMON, Atk.METEORS);
        // служебные
        def("trial", "Страж испытания", EntityType.VINDICATOR, 2.0, 4000, BossBar.Color.WHITE, null, 2, 6f, Atk.QUAKE, Atk.SUMMON);
        def("guard_fire", "Страж печати: Огонь", EntityType.VINDICATOR, 2.0, 5000, BossBar.Color.RED, "fire_core", 2, 7f, Atk.LAVA_WAVE, Atk.METEORS);
        def("guard_water", "Страж печати: Вода", EntityType.VINDICATOR, 2.0, 5000, BossBar.Color.BLUE, "water_core", 2, 7f, Atk.TIDAL, Atk.ICE_NOVA);
        def("guard_earth", "Страж печати: Земля", EntityType.VINDICATOR, 2.0, 5000, BossBar.Color.GREEN, "earth_core", 2, 7f, Atk.QUAKE, Atk.ROOTS);
        def("guard_air", "Страж печати: Воздух", EntityType.VINDICATOR, 2.0, 5000, BossBar.Color.WHITE, "air_core", 2, 7f, Atk.LIGHTNING, Atk.SKY_SPEARS);
        def("god", "БОГ РАЗРУШЕНИЯ", EntityType.WARDEN, 2.5, 100000, BossBar.Color.RED, null, 6, 14f,
                Atk.METEORS, Atk.BLACK_HOLE, Atk.SKY_SPEARS, Atk.LAVA_WAVE, Atk.QUAKE, Atk.SUMMON);
    }

    public static final class Boss {
        public final Def def; public final MobEntity mob; double hp; final double maxHp;
        final ServerBossBar bar; final Set<UUID> damagers = new HashSet<>();
        int age, phase = 1, atkIdx;
        Boss(Def d, MobEntity m, double maxHp) {
            def = d; mob = m; hp = maxHp; this.maxHp = maxHp;
            bar = new ServerBossBar(Text.literal("§l" + d.name()), d.color(), BossBar.Style.NOTCHED_10);
        }
    }
    private static final List<Boss> ACTIVE = new ArrayList<>();

    public static List<Boss> active() { return ACTIVE; }

    public static Boss spawn(Def d, ServerWorld w, Vec3d pos, double hpMult) {
        MobEntity m = d.type().create(w);
        if (m == null) return null;
        m.refreshPositionAndAngles(pos.x, pos.y, pos.z, 0, 0);
        set(m, EntityAttributes.GENERIC_MAX_HEALTH, 1024);
        m.setHealth(1024f);
        set(m, EntityAttributes.GENERIC_SCALE, d.scale());
        m.setCustomName(Text.literal("§c" + d.name()));
        m.setCustomNameVisible(true);
        m.setPersistent();
        m.addCommandTag("arcana_boss");
        w.spawnEntity(m);
        Boss b = new Boss(d, m, d.hp() * hpMult);
        ACTIVE.add(b);
        Fx.puff(w, ParticleTypes.EXPLOSION_EMITTER, pos, 1, 0, 0);
        Fx.sound(w, pos, SoundEvents.ENTITY_ENDER_DRAGON_GROWL, 0.7f);
        w.getServer().getPlayerManager().broadcast(Text.literal("§4☠ Появился босс: §c" + d.name()), false);
        return b;
    }

    private static void set(MobEntity m, net.minecraft.registry.entry.RegistryEntry<net.minecraft.entity.attribute.EntityAttribute> a, double v) {
        EntityAttributeInstance i = m.getAttributeInstance(a);
        if (i != null) i.setBaseValue(v);
    }

    public static boolean isBoss(Entity e) { return e.getCommandTags().contains("arcana_boss"); }

    private static Boss of(Entity e) {
        for (Boss b : ACTIVE) if (b.mob == e) return b;
        return null;
    }

    /** Вызывается из AFTER_DAMAGE. */
    public static void onDamage(LivingEntity e, DamageSource src, float taken, MinecraftServer s) {
        Boss b = of(e);
        if (b == null) return;
        ServerPlayerEntity who = Minions.ownerPlayer(s, src.getAttacker());
        if (who != null) b.damagers.add(who.getUuid());
        b.hp -= taken;
        b.mob.setHealth(b.mob.getMaxHealth());
        if (b.hp <= 0) finish(b, s, true);
    }

    public static void tick(MinecraftServer s) {
        Iterator<Boss> it = new ArrayList<>(ACTIVE).iterator();
        while (it.hasNext()) {
            Boss b = it.next();
            if (!b.mob.isAlive()) { finish(b, s, b.hp <= 0 || b.mob.isDead()); continue; }
            ServerWorld w = (ServerWorld) b.mob.getWorld();
            b.age++;
            if (b.mob.getHealth() < b.mob.getMaxHealth()) b.mob.setHealth(b.mob.getMaxHealth());
            double pct = Math.max(0, b.hp / b.maxHp);
            b.bar.setPercent((float) pct);
            int phase = pct > 0.66 ? 1 : pct > 0.33 ? 2 : 3;
            if (phase != b.phase) {
                b.phase = phase;
                s.getPlayerManager().broadcast(Text.literal("§c" + b.def.name() + " §7входит в фазу §c" + phase), false);
                Fx.sound(w, b.mob.getPos(), SoundEvents.ENTITY_WITHER_SPAWN, 0.8f);
            }
            List<ServerPlayerEntity> near = w.getPlayers(p -> p.isAlive() && !p.isSpectator() && p.squaredDistanceTo(b.mob) <= 40 * 40);
            for (ServerPlayerEntity p : w.getPlayers()) {
                if (p.squaredDistanceTo(b.mob) <= 64 * 64) b.bar.addPlayer(p); else b.bar.removePlayer(p);
            }
            int period = phase == 1 ? 60 : phase == 2 ? 45 : 30;
            if (!near.isEmpty() && b.age % period == 0) {
                Atk a = b.def.attacks().get(b.atkIdx++ % b.def.attacks().size());
                attack(b, a, w, near, b.def.dmg() * (1f + 0.35f * (phase - 1)));
            }
        }
    }

    // ───────────── атаки ─────────────
    private static void strike(ServerWorld w, Vec3d pos, double radius, float dmg, int delay, ParticleEffect warn,
                               ParticleEffect hit, Consumer<ServerPlayerEntity> extra) {
        for (int i = 0; i < delay; i += 4) Scheduler.later(w.getServer(), i, () -> Fx.puff(w, warn, pos.add(0, 0.2, 0), 6, radius / 2, 0.01));
        Scheduler.later(w.getServer(), delay, () -> {
            Fx.puff(w, hit, pos.add(0, 0.5, 0), 40, radius / 2, 0.1);
            Fx.sound(w, pos, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 0.8f);
            for (ServerPlayerEntity p : w.getPlayers(x -> x.isAlive() && x.squaredDistanceTo(pos) <= radius * radius)) {
                p.damage(w.getDamageSources().magic(), dmg);
                if (extra != null) extra.accept(p);
            }
        });
    }

    private static void attack(Boss b, Atk a, ServerWorld w, List<ServerPlayerEntity> ps, float dmg) {
        Vec3d c = b.mob.getPos();
        MinecraftServer s = w.getServer();
        switch (a) {
            case ICE_NOVA -> {
                for (ServerPlayerEntity p : ps) if (p.squaredDistanceTo(b.mob) <= 144) {
                    p.damage(w.getDamageSources().magic(), dmg);
                    Fx.buff(p, StatusEffects.SLOWNESS, 4, 1);
                    p.setFrozenTicks(140);
                }
                Fx.puff(w, ParticleTypes.SNOWFLAKE, c.add(0, 1, 0), 200, 6, 0.2);
                Fx.sound(w, c, SoundEvents.BLOCK_GLASS_BREAK, 0.6f);
            }
            case LAVA_WAVE -> {
                for (ServerPlayerEntity p : ps) if (p.squaredDistanceTo(b.mob) <= 196) { p.damage(w.getDamageSources().magic(), dmg); p.setOnFireFor(5); }
                Fx.puff(w, ParticleTypes.LAVA, c.add(0, 0.5, 0), 120, 7, 0.1);
                Fx.sound(w, c, SoundEvents.ENTITY_BLAZE_SHOOT, 0.5f);
            }
            case METEORS -> {
                for (ServerPlayerEntity p : ps) for (int i = 0; i < b.phase + 1; i++) {
                    Vec3d t = p.getPos().add((p.getRandom().nextDouble() - 0.5) * 8, 0, (p.getRandom().nextDouble() - 0.5) * 8);
                    strike(w, t, 3, dmg * 1.5f, 25, ParticleTypes.FLAME, ParticleTypes.EXPLOSION, pl -> pl.setOnFireFor(3));
                }
            }
            case SKY_SPEARS -> {
                for (ServerPlayerEntity p : ps) strike(w, p.getPos(), 2.5, dmg, 20, ParticleTypes.END_ROD, ParticleTypes.GLOW,
                        pl -> CastManager.silence(pl, 80));
            }
            case BLACK_HOLE -> {
                for (int i = 0; i < 12; i++) Scheduler.later(s, i * 5, () -> {
                    for (ServerPlayerEntity p : w.getPlayers(x -> x.isAlive() && x.squaredDistanceTo(c) <= 400)) {
                        Vec3d pull = c.subtract(p.getPos()).normalize().multiply(0.35);
                        p.setVelocity(p.getVelocity().multiply(0.5).add(pull));
                        p.velocityModified = true;
                        if (p.squaredDistanceTo(c) < 25) p.damage(w.getDamageSources().magic(), dmg * 0.3f);
                    }
                    Fx.puff(w, ParticleTypes.SQUID_INK, c.add(0, 1, 0), 40, 2, 0.1);
                });
            }
            case SUMMON -> {
                long adds = w.getEntitiesByClass(MobEntity.class, b.mob.getBoundingBox().expand(24), e -> e.getCommandTags().contains("arcana_add")).size();
                if (adds >= 8) return;
                for (int i = 0; i < 3; i++) {
                    MobEntity m = (i % 2 == 0 ? EntityType.ZOMBIE : EntityType.SKELETON).create(w);
                    if (m == null) continue;
                    m.refreshPositionAndAngles(c.x + (i - 1) * 3, c.y, c.z + 2, 0, 0);
                    m.addCommandTag("arcana_add");
                    m.setCustomName(Text.literal("§7Прислужник"));
                    set(m, EntityAttributes.GENERIC_MAX_HEALTH, 40);
                    m.setHealth(40f);
                    w.spawnEntity(m);
                }
            }
            case SPORE_CLOUD -> {
                for (ServerPlayerEntity p : ps) if (p.squaredDistanceTo(b.mob) <= 144) {
                    Fx.buff(p, StatusEffects.POISON, 6, 1);
                    Fx.buff(p, StatusEffects.SLOWNESS, 4, 1);
                    Fx.buff(p, StatusEffects.NAUSEA, 5, 0);
                }
                Fx.puff(w, ParticleTypes.SPORE_BLOSSOM_AIR, c.add(0, 1, 0), 200, 6, 0.05);
            }
            case LIGHTNING -> {
                for (ServerPlayerEntity p : ps) strike(w, p.getPos(), 2.5, dmg, 15, ParticleTypes.ELECTRIC_SPARK, ParticleTypes.ELECTRIC_SPARK, pl -> {
                    net.minecraft.entity.LightningEntity l = EntityType.LIGHTNING_BOLT.create(w);
                    if (l != null) { l.refreshPositionAfterTeleport(pl.getPos()); w.spawnEntity(l); }
                });
            }
            case SAND_STORM -> {
                for (ServerPlayerEntity p : ps) if (p.squaredDistanceTo(b.mob) <= 256) {
                    p.damage(w.getDamageSources().magic(), dmg * 0.6f);
                    Fx.buff(p, StatusEffects.BLINDNESS, 3, 0);
                    Fx.buff(p, StatusEffects.SLOWNESS, 3, 1);
                }
                Fx.puff(w, ParticleTypes.CAMPFIRE_COSY_SMOKE, c.add(0, 1, 0), 150, 8, 0.1);
            }
            case CRYSTAL_SPIKES -> {
                for (ServerPlayerEntity p : ps) strike(w, p.getPos(), 2.5, dmg, 20, ParticleTypes.ENCHANT, ParticleTypes.END_ROD, pl -> {
                    pl.setVelocity(pl.getVelocity().add(0, 0.9, 0));
                    pl.velocityModified = true;
                });
            }
            case SOUL_DRAIN -> {
                for (ServerPlayerEntity p : ps) if (p.squaredDistanceTo(b.mob) <= 196) {
                    p.damage(w.getDamageSources().magic(), dmg * 0.5f);
                    Fx.buff(p, StatusEffects.WITHER, 3, 0);
                    Fx.beam(w, ParticleTypes.SOUL, p.getPos().add(0, 1, 0), c.add(0, 2, 0));
                    b.hp = Math.min(b.maxHp, b.hp + b.maxHp * 0.005);
                }
            }
            case ROOTS -> {
                for (ServerPlayerEntity p : ps) if (p.squaredDistanceTo(b.mob) <= 225) {
                    p.damage(w.getDamageSources().magic(), dmg);
                    Fx.buff(p, StatusEffects.SLOWNESS, 3, 6);
                    Fx.puff(w, ParticleTypes.COMPOSTER, p.getPos(), 30, 0.5, 0.1);
                }
            }
            case TIDAL -> {
                for (ServerPlayerEntity p : ps) if (p.squaredDistanceTo(b.mob) <= 225) {
                    p.damage(w.getDamageSources().magic(), dmg);
                    Vec3d off = p.getPos().subtract(c);
                    Vec3d h = new Vec3d(off.x, 0, off.z).normalize().multiply(1.4);
                    p.setVelocity(h.x, 0.4, h.z);
                    p.velocityModified = true;
                    Fx.buff(p, StatusEffects.NAUSEA, 4, 0);
                }
                Fx.puff(w, ParticleTypes.SPLASH, c.add(0, 1, 0), 200, 6, 0.3);
            }
            case QUAKE -> {
                for (ServerPlayerEntity p : ps) if (p.squaredDistanceTo(b.mob) <= 100) {
                    p.damage(w.getDamageSources().magic(), dmg);
                    p.setVelocity(p.getVelocity().add(0, 0.9, 0));
                    p.velocityModified = true;
                }
                Fx.puff(w, ParticleTypes.CLOUD, c.add(0, 0.2, 0), 120, 5, 0.1);
                Fx.sound(w, c, SoundEvents.BLOCK_ANVIL_LAND, 0.4f);
            }
        }
    }

    // ───────────── смерть ─────────────
    public static void finish(Boss b, MinecraftServer s, boolean killed) {
        if (!ACTIVE.remove(b)) return;
        b.bar.clearPlayers();
        if (b.mob.isAlive()) b.mob.kill();
        if (!killed) return;
        ServerWorld w = (ServerWorld) b.mob.getWorld();
        Fx.puff(w, ParticleTypes.TOTEM_OF_UNDYING, b.mob.getPos().add(0, 1, 0), 150, 2, 0.4);
        s.getPlayerManager().broadcast(Text.literal("§a✔ Босс повержен: §f" + b.def.name()), false);
        int xp = (int) Math.max(50, b.def.hp() / 20);
        for (UUID id : b.damagers) {
            ServerPlayerEntity p = s.getPlayerManager().getPlayer(id);
            if (p == null) continue;
            Progression.giveXp(p, xp);
            Guilds.onBoss(p);
            ArcanaClass c = CastManager.cls(p);
            if (b.def.drop() != null) {
                Item it = ModItems.RESOURCES.get(b.def.drop());
                ItemStack st = new ItemStack(it, 1 + p.getRandom().nextInt(2));
                if (!p.giveItemStack(st)) p.dropItem(st, false);
            }
            if (c != null && b.def.rarity() > 0 && !b.def.id().startsWith("guard_") && !b.def.id().equals("trial")) {
                ItemStack wst = Weapons.create(c, Rarity.of(b.def.rarity()));
                if (!p.giveItemStack(wst)) p.dropItem(wst, false);
            }
            if (!b.def.id().startsWith("guard_") && !b.def.id().equals("trial")) {
                int tier = Math.max(0, Math.min(6, b.def.rarity() - 1 + p.getRandom().nextInt(2)));
                ItemStack art = Artifacts.forBoss(b.def.id(), tier);
                if (art != null && !p.giveItemStack(art)) p.dropItem(art, false);
                if (p.getRandom().nextInt(100) < 30) { ItemStack egg = Pets.randomEgg(p.getRandom()); if (!p.giveItemStack(egg)) p.dropItem(egg, false); }
            }
            if (b.def.id().equals("trial") && Progression_trial(p)) { /* сообщение внутри */ }
        }
        RuinsWorld.onBossKilled(b.def.id());
        FallOfCreation.onBossDeath(b.def.id(), s);
    }

    private static boolean Progression_trial(ServerPlayerEntity p) {
        PlayerData d = CastManager.data(p);
        if (d.level() < Progression.TRIAL_LEVEL) { p.sendMessage(Text.literal("§7Испытание пройдено, но нужен уровень " + Progression.TRIAL_LEVEL + "."), false); return false; }
        CastManager.save(p, d.withTrial(true));
        p.sendMessage(Text.literal("§6Классовое испытание пройдено! Пробуждение: /arcana awaken (уровень " + Progression.AWAKEN_LEVEL + "+)"), false);
        return true;
    }
}
