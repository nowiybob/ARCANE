package com.arcana;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;

import java.util.List;
import java.util.Set;

import static com.arcana.ArcanaClass.*;

/** Свойства 11 биомов измерения «Руины»: босс, подходящие классы, материалы построек. */
public record BiomeInfo(String id, String name, String boss, Set<ArcanaClass> suits, Block floor, Block accent, Block pillar) {
    public static final List<BiomeInfo> ALL = List.of(
        new BiomeInfo("permafrost", "Вечная мерзлота", "verdax", Set.of(CHRONOMAGE, DRAGONOR), Blocks.PACKED_ICE, Blocks.STONE_BRICKS, Blocks.BLUE_ICE),
        new BiomeInfo("ash_wasteland", "Пепельные пустоши", "ignis", Set.of(TITAN, DRAGONOR), Blocks.POLISHED_BLACKSTONE_BRICKS, Blocks.BLACKSTONE, Blocks.CHISELED_POLISHED_BLACKSTONE),
        new BiomeInfo("forgotten_forest", "Забытый лес", "treant", Set.of(DRUID, SUMMONER), Blocks.MOSSY_STONE_BRICKS, Blocks.MOSS_BLOCK, Blocks.OAK_LOG),
        new BiomeInfo("void", "Пустота", "abyss", Set.of(PHANTOM, ARCANIST), Blocks.OBSIDIAN, Blocks.PURPUR_BLOCK, Blocks.PURPUR_PILLAR),
        new BiomeInfo("sky_islands", "Небесные острова", "seraph", Set.of(RANGER, SOLARIS), Blocks.QUARTZ_BRICKS, Blocks.SMOOTH_QUARTZ, Blocks.QUARTZ_PILLAR),
        new BiomeInfo("sunken_kingdom", "Затонувшее царство", "leviathan", Set.of(ALCHEMIST, SUMMONER), Blocks.PRISMARINE_BRICKS, Blocks.DARK_PRISMARINE, Blocks.PRISMARINE),
        new BiomeInfo("thunder_peaks", "Грозовые пики", "thorax", Set.of(STORMCALLER), Blocks.CUT_COPPER, Blocks.WEATHERED_CUT_COPPER, Blocks.EXPOSED_CUT_COPPER),
        new BiomeInfo("golden_sands", "Золотые пески", "pharaoh", Set.of(CHRONOMAGE, PHANTOM), Blocks.CUT_SANDSTONE, Blocks.SMOOTH_SANDSTONE, Blocks.CHISELED_SANDSTONE),
        new BiomeInfo("crimson_swamps", "Багровые болота", "sporemother", Set.of(NECROMANCER, ALCHEMIST), Blocks.MUD_BRICKS, Blocks.PACKED_MUD, Blocks.MANGROVE_LOG),
        new BiomeInfo("crystal_depths", "Кристальные глубины", "crystal", Set.of(TITAN, ALCHEMIST), Blocks.AMETHYST_BLOCK, Blocks.CALCITE, Blocks.AMETHYST_BLOCK),
        new BiomeInfo("dead_lands", "Мёртвые земли", "malakhar", Set.of(NECROMANCER, PHANTOM), Blocks.DEEPSLATE_BRICKS, Blocks.SOUL_SOIL, Blocks.POLISHED_DEEPSLATE)
    );

    public static BiomeInfo byId(String id) {
        for (BiomeInfo b : ALL) if (b.id.equals(id)) return b;
        return null;
    }
    public static BiomeInfo byBoss(String boss) {
        for (BiomeInfo b : ALL) if (b.boss.equals(boss)) return b;
        return null;
    }
    public String suitsText() {
        StringBuilder sb = new StringBuilder();
        for (ArcanaClass c : suits) { if (sb.length() > 0) sb.append(", "); sb.append(c.displayName); }
        return sb.toString();
    }
}
