package com.arcana;

import java.util.List;

public enum ArcanaClass {
    DRAGONOR("dragonor", "Драконор", "Повелитель драконьей крови", "Драконья ярость: каждое попадание восстанавливает 3 маны",
            1.0, 1.0, Abilities.DRAGONOR, "Клык дракона", "Драконья форма"),
    ARCANIST("arcanist", "Арканист", "Маг первородного хаоса", "Поток магии: мана восстанавливается на 50% быстрее",
            1.5, 1.0, Abilities.ARCANIST, "Посох хаоса", "Абсолютная магия"),
    PHANTOM("phantom", "Фантом", "Мастер теней", "Теневая энергия: нет урона от падения",
            1.0, 1.0, Abilities.PHANTOM, "Теневой кинжал", "Повелитель теней"),
    TITAN("titan", "Титан", "Непробиваемая крепость", "Ярость: получив урон, 5 секунд получаете Силу",
            1.0, 1.0, Abilities.TITAN, "Молот колосса", "Древний исполин"),
    SOLARIS("solaris", "Соларис", "Воин солнечного света", "Солнечная энергия: днём под открытым небом мана восстанавливается в 1.5 раза быстрее",
            1.0, 1.0, Abilities2.SOLARIS, "Солнечный клинок", "Солнечный аватар"),
    NECROMANCER("necromancer", "Некромант", "Хозяин душ", "Сбор душ: убийство восстанавливает 5 маны",
            1.0, 1.0, Abilities2.NECROMANCER, "Книга душ", "Король смерти"),
    SUMMONER("summoner", "Призыватель", "Хозяин древних существ", "Связь духов: призванные существа живут в 1.5 раза дольше",
            1.0, 1.0, Abilities2.SUMMONER, "Жезл духов", "Создатель легиона"),
    STORMCALLER("stormcaller", "Буревестник", "Повелитель грозы", "Заряд: каждое попадание даёт Скорость на 3 секунды",
            1.0, 1.0, Abilities2.STORMCALLER, "Копьё бури", "Бог грозы"),
    RANGER("ranger", "Рейнджер", "Легендарный охотник", "Метка охотника: попадание подсвечивает цель, по подсвеченным +20% урона способностей",
            1.0, 1.0, Abilities2.RANGER, "Лук охотника", "Охотник богов"),
    ALCHEMIST("alchemist", "Алхимик", "Создатель невозможного", "Походная лаборатория: раз в минуту создаёт случайное зелье",
            1.0, 1.0, Abilities2.ALCHEMIST, "Реторта алхимика", "Совершенная форма"),
    DRUID("druid", "Друид", "Душа древнего леса", "Дар леса: медленно восстанавливает здоровье",
            1.0, 1.0, Abilities2.DRUID, "Посох леса", "Древний хранитель"),
    CHRONOMAGE("chronomage", "Хрономаг", "Повелитель времени", "Власть над временем: перезарядки способностей на 10% короче",
            1.0, 0.9, Abilities2.CHRONOMAGE, "Часы древних", "Вечность");

    public final String id, displayName, title, passive, weaponName, awakening;
    public final double manaRegenMult, cdMult;
    public final List<Ability> abilities;

    ArcanaClass(String id, String displayName, String title, String passive, double regen, double cd,
                List<Ability> abilities, String weaponName, String awakening) {
        this.id = id; this.displayName = displayName.replace("\u00AD", ""); this.title = title; this.passive = passive;
        this.manaRegenMult = regen; this.cdMult = cd; this.abilities = abilities;
        this.weaponName = weaponName; this.awakening = awakening;
    }

    public static ArcanaClass byId(String id) {
        for (ArcanaClass c : values()) if (c.id.equalsIgnoreCase(id)) return c;
        return null;
    }
}
