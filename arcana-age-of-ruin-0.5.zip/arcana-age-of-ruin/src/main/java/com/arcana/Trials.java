package com.arcana;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/** Классовые испытания у алтарей (Lodestone в Руинах). Вид испытания зависит от класса. */
public final class Trials {
    enum Kind { WAVES, SURVIVE, GUARDIAN }

    private static final class T {
        Kind kind; ServerWorld w; Vec3d center; long start; int kills, goal, spawned;
    }
    private static final Map<UUID, T> ACTIVE = new HashMap<>();
    private static final String TAG = "arcana_trial_";

    static Kind kindFor(ArcanaClass c) {
        return switch (c) {
            case DRAGONOR, TITAN, SOLARIS, STORMCALLER -> Kind.WAVES;
            case PHANTOM, RANGER -> Kind.GUARDIAN;
            default -> Kind.SURVIVE;
        };
    }

    static String describe(Kind k) {
        return switch (k) {
            case WAVES -> "победить волны из 20 противников";
            case SURVIVE -> "продержаться 90 секунд против нарастающих волн";
            case GUARDIAN -> "победить Стража испытания";
        };
    }

    public static void start(ServerPlayerEntity p, BlockPos altar) {
        ArcanaClass c = CastManager.cls(p);
        ServerWorld w = (ServerWorld) p.getWorld();
        BiomeInfo b = RuinsWorld.biomeAt(w, altar);
        PlayerData d = CastManager.data(p);
        if (c == null) { p.sendMessage(Text.literal("§cСначала выбери класс."), true); return; }
        if (b == null) return;
        if (ACTIVE.containsKey(p.getUuid())) { p.sendMessage(Text.literal("§7Испытание уже идёт."), true); return; }
        if (d.trial()) { p.sendMessage(Text.literal("§7Ты уже прошёл классовое испытание."), true); return; }
        if (d.level() < Progression.TRIAL_LEVEL) { p.sendMessage(Text.literal("§cАлтарь молчит: нужен уровень " + Progression.TRIAL_LEVEL + "."), true); return; }
        if (!b.suits().contains(c)) { p.sendMessage(Text.literal("§cАлтарь не признаёт твой класс. Подходят: " + b.suitsText()), false); return; }

        T t = new T();
        t.kind = kindFor(c); t.w = w; t.center = Vec3d.ofBottomCenter(altar).add(0, 1, 0); t.start = p.getServer().getTicks();
        t.goal = t.kind == Kind.WAVES ? 20 : 0;
        ACTIVE.put(p.getUuid(), t);
        p.getServer().getPlayerManager().broadcast(Text.literal("§5✦ " + p.getName().getString() + " начал классовое испытание: §f" + describe(t.kind)), false);
        if (t.kind == Kind.GUARDIAN) {
            Bosses.spawn(Bosses.DEFS.get("trial"), w, t.center.add(5, 0, 0), 1.0 + d.level() / 50.0);
        }
    }

    private static void spawn(T t, ServerPlayerEntity p, int n) {
        EntityType<?>[] pool = {EntityType.ZOMBIE, EntityType.SKELETON, EntityType.PILLAGER, EntityType.VINDICATOR};
        double mult = 2 + CastManager.data(p).level() / 40.0;
        for (int i = 0; i < n; i++) {
            double a = p.getRandom().nextDouble() * Math.PI * 2, d = 8 + p.getRandom().nextDouble() * 4;
            double x = t.center.x + Math.cos(a) * d, z = t.center.z + Math.sin(a) * d;
            int y = t.w.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, (int) x, (int) z);
            MobEntity m = (MobEntity) pool[p.getRandom().nextInt(pool.length)].create(t.w);
            if (m == null) continue;
            m.refreshPositionAndAngles(x, y, z, 0, 0);
            m.addCommandTag(TAG + p.getUuid());
            m.setCustomName(Text.literal("§5Страж испытания"));
            m.setPersistent();
            EntityAttributeInstance hp = m.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH);
            if (hp != null) { hp.setBaseValue(hp.getBaseValue() * mult); m.setHealth((float) hp.getBaseValue()); }
            m.setTarget(p);
            t.w.spawnEntity(m);
            t.spawned++;
        }
    }

    public static void tick(MinecraftServer s) {
        if (s.getTicks() % 20 != 0) return;
        Iterator<Map.Entry<UUID, T>> it = ACTIVE.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, T> e = it.next();
            T t = e.getValue();
            ServerPlayerEntity p = s.getPlayerManager().getPlayer(e.getKey());
            if (p == null || !p.isAlive() || p.getWorld() != t.w || p.squaredDistanceTo(t.center) > 60 * 60) {
                if (p != null) p.sendMessage(Text.literal("§cИспытание провалено."), false);
                cleanup(t, e.getKey());
                it.remove();
                continue;
            }
            long sec = (s.getTicks() - t.start) / 20;
            switch (t.kind) {
                case WAVES -> {
                    if (sec % 15 == 0 && t.spawned < t.goal) spawn(t, p, 5);
                    p.sendMessage(Text.literal("§5Испытание: §f" + t.kills + "/" + t.goal), true);
                    if (t.kills >= t.goal) { complete(p); cleanup(t, e.getKey()); it.remove(); }
                }
                case SURVIVE -> {
                    if (sec % 10 == 0) spawn(t, p, 3 + (int) (sec / 30));
                    p.sendMessage(Text.literal("§5Испытание: держись еще §f" + Math.max(0, 90 - sec) + " с"), true);
                    if (sec >= 90) { complete(p); cleanup(t, e.getKey()); it.remove(); }
                }
                case GUARDIAN -> {
                    if (Bosses.active().stream().noneMatch(b -> b.def.id().equals("trial") && b.mob.getWorld() == t.w)) {
                        // Страж побеждён (награда и флаг испытания выдаются при его смерти)
                        cleanup(t, e.getKey());
                        it.remove();
                    }
                }
            }
        }
    }

    private static void cleanup(T t, UUID id) {
        String tag = TAG + id;
        for (MobEntity m : t.w.getEntitiesByClass(MobEntity.class, new net.minecraft.util.math.Box(t.center, t.center).expand(80), x -> x.getCommandTags().contains(tag))) m.discard();
    }

    private static void complete(ServerPlayerEntity p) {
        PlayerData d = CastManager.data(p);
        CastManager.save(p, d.withTrial(true));
        Progression.giveXp(p, 1500);
        p.getServer().getPlayerManager().broadcast(Text.literal("§6✦ " + p.getName().getString() + " прошёл классовое испытание! Пробуждение: /arcana awaken"), false);
    }

    public static void onKill(MinecraftServer s, Entity e) {
        for (String tag : e.getCommandTags()) {
            if (!tag.startsWith(TAG)) continue;
            try {
                T t = ACTIVE.get(UUID.fromString(tag.substring(TAG.length())));
                if (t != null) t.kills++;
            } catch (IllegalArgumentException ignored) {}
        }
    }
}
