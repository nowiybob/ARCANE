package com.arcana;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Вспомогательные функции: поиск целей, частицы, звуки, урон. */
public final class Fx {
    public static Vec3d center(Entity e) { return e.getPos().add(0, e.getHeight() / 2, 0); }

    public static List<LivingEntity> around(ServerWorld w, Vec3d c, double r, Entity except) {
        return w.getEntitiesByClass(LivingEntity.class, new Box(c, c).expand(r),
                e -> e != except && e.isAlive() && !e.isSpectator() && e.squaredDistanceTo(c) <= r * r);
    }

    /** Все существа вдоль линии взгляда, ближние первыми. */
    public static List<LivingEntity> along(ServerPlayerEntity p, double range, double radius) {
        Vec3d eye = p.getEyePos();
        Vec3d dir = p.getRotationVec(1f);
        Box box = p.getBoundingBox().stretch(dir.multiply(range)).expand(radius + 1);
        List<LivingEntity> out = new ArrayList<>();
        for (LivingEntity e : p.getServerWorld().getEntitiesByClass(LivingEntity.class, box,
                x -> x != p && x.isAlive() && !x.isSpectator())) {
            Vec3d to = center(e).subtract(eye);
            double t = to.dotProduct(dir);
            if (t < 0 || t > range) continue;
            double dist = to.subtract(dir.multiply(t)).length();
            if (dist <= radius + e.getWidth() / 2) out.add(e);
        }
        out.sort(Comparator.comparingDouble(e -> e.squaredDistanceTo(p)));
        return out;
    }

    public static LivingEntity firstTarget(ServerPlayerEntity p, double range) {
        List<LivingEntity> l = along(p, range, 0.8);
        return l.isEmpty() ? null : l.get(0);
    }

    /** Точка, куда смотрит игрок (до блока или на максимальной дальности). */
    public static Vec3d aimPoint(ServerPlayerEntity p, double range) {
        Vec3d eye = p.getEyePos();
        Vec3d end = eye.add(p.getRotationVec(1f).multiply(range));
        HitResult hit = p.getServerWorld().raycast(new RaycastContext(eye, end,
                RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));
        return hit.getPos();
    }

    public static void magic(LivingEntity target, ServerPlayerEntity src, float dmg) {
        double m = Progression.power(src);
        if (CastManager.cls(src) == ArcanaClass.RANGER && target.hasStatusEffect(StatusEffects.GLOWING)) m *= 1.2;
        target.damage(src.getDamageSources().indirectMagic(src, src), (float) (dmg * m));
    }

    public static void buff(LivingEntity e, RegistryEntry<StatusEffect> eff, int sec, int amp) {
        e.addStatusEffect(new StatusEffectInstance(eff, sec * 20, amp));
    }

    public static void puff(ServerWorld w, ParticleEffect t, Vec3d pos, int n, double spread, double speed) {
        w.spawnParticles(t, pos.x, pos.y, pos.z, n, spread, spread, spread, speed);
    }

    public static void beam(ServerWorld w, ParticleEffect t, Vec3d from, Vec3d to) {
        Vec3d d = to.subtract(from);
        int steps = Math.max(1, (int) (d.length() * 2));
        for (int i = 0; i <= steps; i++) {
            Vec3d p = from.add(d.multiply(i / (double) steps));
            w.spawnParticles(t, p.x, p.y, p.z, 1, 0, 0, 0, 0);
        }
    }

    public static List<ServerPlayerEntity> allies(ServerWorld w, ServerPlayerEntity p, double r) {
        return w.getPlayers(x -> x.isAlive() && !x.isSpectator() && x.squaredDistanceTo(p) <= r * r);
    }

    public static void sound(ServerWorld w, Vec3d pos, SoundEvent s, float pitch) {
        w.playSound(null, pos.x, pos.y, pos.z, s, SoundCategory.PLAYERS, 1f, pitch);
    }
}
