package com.arcana;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

import java.util.List;

/** Коллекция питомцев игрока (до 8) и индекс активного. */
public record PetsData(List<Pet> pets, int active) {
    public record Pet(String species, int level, int xp, String name) {
        public static final Codec<Pet> CODEC = RecordCodecBuilder.create(i -> i.group(
                Codec.STRING.fieldOf("species").forGetter(Pet::species),
                Codec.INT.optionalFieldOf("level", 1).forGetter(Pet::level),
                Codec.INT.optionalFieldOf("xp", 0).forGetter(Pet::xp),
                Codec.STRING.optionalFieldOf("name", "").forGetter(Pet::name)
        ).apply(i, Pet::new));
    }

    public static final PetsData EMPTY = new PetsData(List.of(), -1);

    public static final Codec<PetsData> CODEC = RecordCodecBuilder.create(i -> i.group(
            Pet.CODEC.listOf().optionalFieldOf("pets", List.of()).forGetter(PetsData::pets),
            Codec.INT.optionalFieldOf("active", -1).forGetter(PetsData::active)
    ).apply(i, PetsData::new));
}
